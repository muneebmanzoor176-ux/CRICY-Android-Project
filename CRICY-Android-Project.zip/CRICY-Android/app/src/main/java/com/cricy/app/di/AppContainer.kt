package com.cricy.app.di

import android.content.Context
import com.cricy.app.data.local.CricyDatabase
import com.cricy.app.data.preferences.SettingsDataStore
import com.cricy.app.data.repository.CricyRepository

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val database: CricyDatabase by lazy { CricyDatabase.getInstance(appContext) }
    val settingsDataStore: SettingsDataStore by lazy { SettingsDataStore(appContext) }
    val repository: CricyRepository by lazy {
        CricyRepository(
            context = appContext,
            database = database,
            settingsDataStore = settingsDataStore
        )
    }
}
