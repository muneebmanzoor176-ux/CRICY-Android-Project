package com.cricy.app.domain.stats

import com.cricy.app.data.local.entity.DeliveryEntity
import com.cricy.app.data.local.entity.MatchEntity
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import com.cricy.app.domain.engine.CricketScoringEngine
import com.cricy.app.domain.model.ExtraType
import com.cricy.app.domain.model.MatchBattingPerformance
import com.cricy.app.domain.model.MatchBowlingPerformance
import com.cricy.app.domain.model.PlayerCareerStats
import com.cricy.app.domain.model.WicketType

/**
 * Computes live and historical individual player batting & bowling career statistics
 * directly from Room deliveries so every ball automatically updates player profiles
 * and leaderboards.
 */
object PlayerStatsCalculator {

    private data class InningsBatKey(val matchId: Long, val inningsNumber: Int, val playerId: Long)
    private data class InningsBowlKey(val matchId: Long, val inningsNumber: Int, val playerId: Long)
    private data class OverKey(val matchId: Long, val inningsNumber: Int, val overNumber: Int, val bowlerId: Long)

    private class BatAcc {
        var runs = 0
        var balls = 0
        var fours = 0
        var sixes = 0
        var isOut = false
        var dismissalText = "not out"
    }

    private class BowlAcc {
        var legalBalls = 0
        var runsConceded = 0
        var wickets = 0
        var maidens = 0
    }

    fun calculateAllPlayerStats(
        players: List<PlayerEntity>,
        teams: List<TeamEntity>,
        matches: List<MatchEntity>,
        deliveries: List<DeliveryEntity>
    ): List<PlayerCareerStats> {
        val teamMap = teams.associateBy { it.id }
        val matchMap = matches.associateBy { it.id }

        // Track squad participation per player
        val matchesPerPlayer = mutableMapOf<Long, MutableSet<Long>>()
        for (match in matches) {
            val squadIds = (CricketScoringEngine.parseIdList(match.teamASquadIdsCsv) +
                CricketScoringEngine.parseIdList(match.teamBSquadIdsCsv)).toSet()
            for (pid in squadIds) {
                matchesPerPlayer.getOrPut(pid) { mutableSetOf() }.add(match.id)
            }
        }

        val battingByInnings = mutableMapOf<InningsBatKey, BatAcc>()
        val bowlingByInnings = mutableMapOf<InningsBowlKey, BowlAcc>()
        val overRuns = mutableMapOf<OverKey, Int>()
        val overLegalBalls = mutableMapOf<OverKey, Int>()

        val sortedDeliveries = deliveries.sortedWith(
            compareBy<DeliveryEntity> { it.matchId }
                .thenBy { it.inningsNumber }
                .thenBy { it.sequenceNumber }
        )

        val playerMap = players.associateBy { it.id }

        for (d in sortedDeliveries) {
            matchesPerPlayer.getOrPut(d.strikerId) { mutableSetOf() }.add(d.matchId)
            matchesPerPlayer.getOrPut(d.nonStrikerId) { mutableSetOf() }.add(d.matchId)
            matchesPerPlayer.getOrPut(d.bowlerId) { mutableSetOf() }.add(d.matchId)

            val extraType = ExtraType.fromString(d.extraType)
            val wicketType = WicketType.fromString(d.wicketType)

            // Ensure both batters on crease have an innings entry
            val strikerAcc = battingByInnings.getOrPut(InningsBatKey(d.matchId, d.inningsNumber, d.strikerId)) { BatAcc() }
            battingByInnings.getOrPut(InningsBatKey(d.matchId, d.inningsNumber, d.nonStrikerId)) { BatAcc() }

            if (extraType != ExtraType.WIDE) {
                strikerAcc.balls += 1
            }
            if (d.runsOffBat > 0) {
                strikerAcc.runs += d.runsOffBat
                if (d.runsOffBat == 4) strikerAcc.fours += 1
                if (d.runsOffBat == 6) strikerAcc.sixes += 1
            }

            if (d.isWicket) {
                val outPlayerId = d.dismissedPlayerId ?: d.strikerId
                val outAcc = battingByInnings.getOrPut(InningsBatKey(d.matchId, d.inningsNumber, outPlayerId)) { BatAcc() }
                outAcc.isOut = true
                val bowlerName = playerMap[d.bowlerId]?.name ?: "Bowler"
                val fielderName = d.fielderId?.let { playerMap[it]?.name }
                outAcc.dismissalText = when (wicketType) {
                    WicketType.BOWLED -> "b $bowlerName"
                    WicketType.CAUGHT -> if (fielderName != null) "c $fielderName b $bowlerName" else "c & b $bowlerName"
                    WicketType.LBW -> "lbw b $bowlerName"
                    WicketType.RUN_OUT -> if (fielderName != null) "run out ($fielderName)" else "run out"
                    WicketType.STUMPED -> if (fielderName != null) "st $fielderName b $bowlerName" else "st b $bowlerName"
                    WicketType.HIT_WICKET -> "hit wicket b $bowlerName"
                    WicketType.NONE -> "out"
                }
            }

            // Bowling accumulation
            val bowlAcc = bowlingByInnings.getOrPut(InningsBowlKey(d.matchId, d.inningsNumber, d.bowlerId)) { BowlAcc() }
            val bowlerChargedRuns = d.runsOffBat +
                if (extraType == ExtraType.WIDE || extraType == ExtraType.NO_BALL) d.extraRuns else 0
            bowlAcc.runsConceded += bowlerChargedRuns
            if (d.countsAsLegalBall) {
                bowlAcc.legalBalls += 1
            }
            if (d.isWicket && wicketType.creditsBowler) {
                bowlAcc.wickets += 1
            }

            val oKey = OverKey(d.matchId, d.inningsNumber, d.overNumber, d.bowlerId)
            overRuns[oKey] = (overRuns[oKey] ?: 0) + bowlerChargedRuns
            if (d.countsAsLegalBall) {
                overLegalBalls[oKey] = (overLegalBalls[oKey] ?: 0) + 1
            }
        }

        // Credit maidens to respective bowling innings
        for ((oKey, ballsInOver) in overLegalBalls) {
            if (ballsInOver == 6 && (overRuns[oKey] ?: 0) == 0) {
                bowlingByInnings[InningsBowlKey(oKey.matchId, oKey.inningsNumber, oKey.bowlerId)]?.let {
                    it.maidens += 1
                }
            }
        }

        // Aggregate per player
        return players.map { player ->
            val team = teamMap[player.teamId]
            val playerBatInnings = battingByInnings.filterKeys { it.playerId == player.id }
            val playerBowlInnings = bowlingByInnings.filterKeys { it.playerId == player.id }

            val inningsBatted = playerBatInnings.size
            val dismissals = playerBatInnings.values.count { it.isOut }
            val notOuts = inningsBatted - dismissals
            val totalRuns = playerBatInnings.values.sumOf { it.runs }
            val totalBalls = playerBatInnings.values.sumOf { it.balls }
            val totalFours = playerBatInnings.values.sumOf { it.fours }
            val totalSixes = playerBatInnings.values.sumOf { it.sixes }
            val centuries = playerBatInnings.values.count { it.runs >= 100 }
            val fifties = playerBatInnings.values.count { it.runs in 50..99 }

            var highScore = 0
            var highScoreNotOut = false
            for (acc in playerBatInnings.values) {
                if (acc.runs > highScore || (acc.runs == highScore && !acc.isOut && highScoreNotOut.not())) {
                    highScore = acc.runs
                    highScoreNotOut = !acc.isOut
                }
            }

            val battingAverage: Double? = if (dismissals > 0) totalRuns.toDouble() / dismissals else null
            val strikeRate: Double = if (totalBalls > 0) (totalRuns * 100.0) / totalBalls else 0.0

            val recentBatting = playerBatInnings.entries.mapNotNull { (key, acc) ->
                val m = matchMap[key.matchId] ?: return@mapNotNull null
                val oppId = if (m.teamAId == player.teamId) m.teamBId else m.teamAId
                val oppShort = teamMap[oppId]?.shortName ?: "OPP"
                MatchBattingPerformance(
                    matchId = m.id,
                    opponentShortName = oppShort,
                    format = m.format,
                    runs = acc.runs,
                    balls = acc.balls,
                    fours = acc.fours,
                    sixes = acc.sixes,
                    isNotOut = !acc.isOut,
                    dismissalText = acc.dismissalText,
                    timestamp = m.updatedAt
                )
            }.sortedByDescending { it.timestamp }

            // Bowling
            val inningsBowled = playerBowlInnings.size
            val legalBallsBowled = playerBowlInnings.values.sumOf { it.legalBalls }
            val maidens = playerBowlInnings.values.sumOf { it.maidens }
            val runsConceded = playerBowlInnings.values.sumOf { it.runsConceded }
            val wicketsTaken = playerBowlInnings.values.sumOf { it.wickets }
            val bowlingAverage: Double? = if (wicketsTaken > 0) runsConceded.toDouble() / wicketsTaken else null
            val economyRate: Double = if (legalBallsBowled > 0) (runsConceded * 6.0) / legalBallsBowled else 0.0

            var bestWickets = -1
            var bestRuns = Int.MAX_VALUE
            for (acc in playerBowlInnings.values) {
                if (acc.wickets > bestWickets || (acc.wickets == bestWickets && acc.runsConceded < bestRuns)) {
                    bestWickets = acc.wickets
                    bestRuns = acc.runsConceded
                }
            }

            val recentBowling = playerBowlInnings.entries.mapNotNull { (key, acc) ->
                val m = matchMap[key.matchId] ?: return@mapNotNull null
                val oppId = if (m.teamAId == player.teamId) m.teamBId else m.teamAId
                val oppShort = teamMap[oppId]?.shortName ?: "OPP"
                MatchBowlingPerformance(
                    matchId = m.id,
                    opponentShortName = oppShort,
                    format = m.format,
                    legalBalls = acc.legalBalls,
                    maidens = acc.maidens,
                    runsConceded = acc.runsConceded,
                    wickets = acc.wickets,
                    timestamp = m.updatedAt
                )
            }.sortedByDescending { it.timestamp }

            PlayerCareerStats(
                player = player,
                team = team,
                matchesPlayed = matchesPerPlayer[player.id]?.size ?: 0,
                inningsBatted = inningsBatted,
                notOuts = notOuts,
                runsScored = totalRuns,
                ballsFaced = totalBalls,
                highestScore = highScore,
                highestScoreNotOut = highScoreNotOut,
                battingAverage = battingAverage,
                strikeRate = strikeRate,
                centuries = centuries,
                fifties = fifties,
                fours = totalFours,
                sixes = totalSixes,
                inningsBowled = inningsBowled,
                legalBallsBowled = legalBallsBowled,
                maidens = maidens,
                runsConceded = runsConceded,
                wicketsTaken = wicketsTaken,
                bowlingAverage = bowlingAverage,
                economyRate = economyRate,
                bestFiguresWickets = if (bestWickets >= 0) bestWickets else 0,
                bestFiguresRuns = if (bestWickets >= 0) bestRuns else 0,
                recentBatting = recentBatting,
                recentBowling = recentBowling
            )
        }
    }
}
