package com.cricy.app.domain.model

import com.cricy.app.data.local.entity.MatchEntity
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity

enum class MatchFormat(val label: String, val defaultOvers: Int) {
    T20("T20", 20),
    ODI("ODI", 50),
    CUSTOM("Custom", 10);

    companion object {
        fun fromString(value: String): MatchFormat =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: T20
    }
}

enum class ExtraType(val label: String, val shortCode: String) {
    NONE("None", ""),
    WIDE("Wide", "Wd"),
    NO_BALL("No Ball", "NB"),
    BYE("Bye", "B"),
    LEG_BYE("Leg Bye", "LB");

    companion object {
        fun fromString(value: String): ExtraType =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: NONE
    }
}

enum class WicketType(val label: String, val creditsBowler: Boolean) {
    NONE("None", false),
    BOWLED("Bowled", true),
    CAUGHT("Caught", true),
    LBW("LBW", true),
    RUN_OUT("Run Out", false),
    STUMPED("Stumped", true),
    HIT_WICKET("Hit Wicket", true);

    companion object {
        fun fromString(value: String): WicketType =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: NONE
    }
}

enum class ScoringCelebration {
    NONE,
    FOUR,
    SIX,
    WICKET,
    INNINGS_BREAK,
    MATCH_WON
}

data class DeliveryChip(
    val id: Long,
    val label: String,
    val isBoundaryFour: Boolean = false,
    val isBoundarySix: Boolean = false,
    val isWicket: Boolean = false,
    val isExtra: Boolean = false
)

data class ExtrasBreakdown(
    val wides: Int = 0,
    val noBalls: Int = 0,
    val byes: Int = 0,
    val legByes: Int = 0
) {
    val total: Int get() = wides + noBalls + byes + legByes
}

data class BatterMatchStats(
    val player: PlayerEntity,
    val runs: Int = 0,
    val balls: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0,
    val isOut: Boolean = false,
    val dismissalText: String = "not out",
    val isOnStrike: Boolean = false
) {
    val strikeRate: Double
        get() = if (balls == 0) 0.0 else (runs * 100.0) / balls
}

data class BowlerMatchStats(
    val player: PlayerEntity,
    val legalBalls: Int = 0,
    val maidens: Int = 0,
    val runsConceded: Int = 0,
    val wickets: Int = 0,
    val wides: Int = 0,
    val noBalls: Int = 0
) {
    val oversDisplay: String
        get() = "${legalBalls / 6}.${legalBalls % 6}"

    val economy: Double
        get() = if (legalBalls == 0) 0.0 else (runsConceded * 6.0) / legalBalls
}

data class PartnershipStats(
    val batterOneName: String,
    val batterTwoName: String,
    val runs: Int,
    val balls: Int,
    val isActive: Boolean
)

data class FallOfWicket(
    val wicketNumber: Int,
    val scoreAtFall: Int,
    val overAtFall: String,
    val batterName: String,
    val dismissalText: String
)

data class InningsScoreboard(
    val inningsNumber: Int,
    val battingTeam: TeamEntity,
    val bowlingTeam: TeamEntity,
    val totalRuns: Int = 0,
    val wickets: Int = 0,
    val legalBalls: Int = 0,
    val oversLimit: Int = 20,
    val maxWickets: Int = 10,
    val extras: ExtrasBreakdown = ExtrasBreakdown(),
    val currentRunRate: Double = 0.0,
    val targetRuns: Int? = null,
    val requiredRuns: Int? = null,
    val remainingBalls: Int = 0,
    val requiredRunRate: Double? = null,
    val batters: List<BatterMatchStats> = emptyList(),
    val bowlers: List<BowlerMatchStats> = emptyList(),
    val partnerships: List<PartnershipStats> = emptyList(),
    val fallOfWickets: List<FallOfWicket> = emptyList(),
    val currentOverChips: List<DeliveryChip> = emptyList(),
    val strikerId: Long? = null,
    val nonStrikerId: Long? = null,
    val currentBowlerId: Long? = null,
    val lastCompletedOverBowlerId: Long? = null,
    val isCompleted: Boolean = false
) {
    val oversDisplay: String
        get() = "${legalBalls / 6}.${legalBalls % 6}"
}

data class MatchLiveState(
    val match: MatchEntity,
    val teamA: TeamEntity,
    val teamB: TeamEntity,
    val teamASquad: List<PlayerEntity>,
    val teamBSquad: List<PlayerEntity>,
    val innings1: InningsScoreboard,
    val innings2: InningsScoreboard?,
    val activeInnings: InningsScoreboard,
    val striker: PlayerEntity?,
    val nonStriker: PlayerEntity?,
    val currentBowler: PlayerEntity?,
    val availableNextBatters: List<PlayerEntity>,
    val availableNextBowlers: List<PlayerEntity>,
    val needsNextBatter: Boolean,
    val needsNextBowler: Boolean,
    val needsSecondInningsOpeners: Boolean,
    val isMatchCompleted: Boolean,
    val resultSummary: String,
    val canUndo: Boolean
)

data class MatchBattingPerformance(
    val matchId: Long,
    val opponentShortName: String,
    val format: String,
    val runs: Int,
    val balls: Int,
    val fours: Int,
    val sixes: Int,
    val isNotOut: Boolean,
    val dismissalText: String,
    val timestamp: Long
)

data class MatchBowlingPerformance(
    val matchId: Long,
    val opponentShortName: String,
    val format: String,
    val legalBalls: Int,
    val maidens: Int,
    val runsConceded: Int,
    val wickets: Int,
    val timestamp: Long
) {
    val oversDisplay: String get() = "${legalBalls / 6}.${legalBalls % 6}"
}

data class PlayerCareerStats(
    val player: PlayerEntity,
    val team: TeamEntity?,
    val matchesPlayed: Int = 0,
    // Batting
    val inningsBatted: Int = 0,
    val notOuts: Int = 0,
    val runsScored: Int = 0,
    val ballsFaced: Int = 0,
    val highestScore: Int = 0,
    val highestScoreNotOut: Boolean = false,
    val battingAverage: Double? = null,
    val strikeRate: Double = 0.0,
    val centuries: Int = 0,
    val fifties: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0,
    // Bowling
    val inningsBowled: Int = 0,
    val legalBallsBowled: Int = 0,
    val maidens: Int = 0,
    val runsConceded: Int = 0,
    val wicketsTaken: Int = 0,
    val bowlingAverage: Double? = null,
    val economyRate: Double = 0.0,
    val bestFiguresWickets: Int = 0,
    val bestFiguresRuns: Int = 0,
    val recentBatting: List<MatchBattingPerformance> = emptyList(),
    val recentBowling: List<MatchBowlingPerformance> = emptyList()
) {
    val oversBowledDisplay: String
        get() = "${legalBallsBowled / 6}.${legalBallsBowled % 6}"

    val highestScoreDisplay: String
        get() = if (inningsBatted == 0) "--" else if (highestScoreNotOut) "$highestScore*" else "$highestScore"

    val bestFiguresDisplay: String
        get() = if (inningsBowled == 0) "--" else "$bestFiguresWickets/$bestFiguresRuns"
}
