package com.cricy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.ui.components.CricyTopBar
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.components.PlayerAvatar
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurfaceBorder
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.viewmodel.PlayerProfileViewModel
import java.util.Locale

@Composable
fun PlayerProfileScreen(
    viewModel: PlayerProfileViewModel,
    onBack: () -> Unit
) {
    val stats by viewModel.playerStats.collectAsState()
    val teams by viewModel.teams.collectAsState()
    var showEditDialog by remember { mutableStateOf(false) }

    val current = stats
    if (current == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CricyBlack)
                .systemBarsPadding(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = GoldPrimary)
        }
        return
    }

    val player = current.player

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding()
    ) {
        CricyTopBar(
            title = "Player Profile",
            subtitle = current.team?.name?.uppercase() ?: "CRICKET PLAYER",
            onBack = onBack,
            trailingAction = {
                IconButton(onClick = { showEditDialog = true }) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = GoldBright)
                }
            }
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Player Header Card
            item {
                MetallicCard(goldHighlight = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlayerAvatar(
                            name = player.name,
                            photoUri = player.photoUri,
                            size = 76.dp,
                            goldRing = true
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = player.name,
                                color = SilverBright,
                                style = MaterialTheme.typography.headlineSmall
                            )
                            Text(
                                text = "${current.team?.name ?: "Club"} · #${player.jerseyNumber}",
                                color = GoldBright,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "${player.role.replace("_", " ")} · ${player.battingStyle}",
                                color = SilverMid,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "Bowling: ${player.bowlingStyle} · ${current.matchesPlayed} Matches",
                                color = SilverMid,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Career Batting Card
            item {
                MetallicCard {
                    Text(
                        text = "CAREER BATTING",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        ProfileStatTile("Runs", current.runsScored.toString(), highlight = true)
                        ProfileStatTile("Average", current.battingAverage?.let { String.format(Locale.US, "%.2f", it) } ?: "--")
                        ProfileStatTile("Strike Rate", String.format(Locale.US, "%.1f", current.strikeRate))
                        ProfileStatTile("High Score", current.highestScoreDisplay)
                    }
                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = CricySurfaceBorder)
                    Spacer(Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        ProfileStatTile("Innings", current.inningsBatted.toString())
                        ProfileStatTile("Not Outs", current.notOuts.toString())
                        ProfileStatTile("100s", current.centuries.toString(), highlight = current.centuries > 0)
                        ProfileStatTile("50s", current.fifties.toString(), highlight = current.fifties > 0)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        ProfileStatTile("Balls", current.ballsFaced.toString())
                        ProfileStatTile("Fours", current.fours.toString())
                        ProfileStatTile("Sixes", current.sixes.toString())
                        ProfileStatTile("Matches", current.matchesPlayed.toString())
                    }
                }
            }

            // Career Bowling Card
            item {
                MetallicCard {
                    Text(
                        text = "CAREER BOWLING",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        ProfileStatTile("Wickets", current.wicketsTaken.toString(), highlight = true)
                        ProfileStatTile("Average", current.bowlingAverage?.let { String.format(Locale.US, "%.2f", it) } ?: "--")
                        ProfileStatTile("Economy", String.format(Locale.US, "%.2f", current.economyRate))
                        ProfileStatTile("Best", current.bestFiguresDisplay, highlight = current.inningsBowled > 0)
                    }
                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = CricySurfaceBorder)
                    Spacer(Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        ProfileStatTile("Innings", current.inningsBowled.toString())
                        ProfileStatTile("Overs", current.oversBowledDisplay)
                        ProfileStatTile("Maidens", current.maidens.toString())
                        ProfileStatTile("Runs", current.runsConceded.toString())
                    }
                }
            }

            // Recent Batting Performances
            if (current.recentBatting.isNotEmpty()) {
                item {
                    Text(
                        text = "RECENT BATTING INNINGS",
                        color = SilverMid,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }
                items(current.recentBatting.take(10)) { perf ->
                    MetallicCard(contentPadding = PaddingValues(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "vs ${perf.opponentShortName} · ${perf.format}",
                                    color = SilverBright,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = perf.dismissalText,
                                    color = SilverMid,
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = "${perf.runs}${if (perf.isNotOut) "*" else ""} (${perf.balls})",
                                color = GoldBright,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }

            // Recent Bowling Performances
            if (current.recentBowling.isNotEmpty()) {
                item {
                    Text(
                        text = "RECENT BOWLING SPELLS",
                        color = SilverMid,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }
                items(current.recentBowling.take(10)) { perf ->
                    MetallicCard(contentPadding = PaddingValues(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "vs ${perf.opponentShortName} · ${perf.format}",
                                    color = SilverBright,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "${perf.oversDisplay} ov · ${perf.maidens} maidens",
                                    color = SilverMid,
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = "${perf.wickets}/${perf.runsConceded}",
                                color = GoldBright,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }

    if (showEditDialog && teams.isNotEmpty()) {
        PlayerEditorDialog(
            initial = player,
            teams = teams,
            defaultTeamId = player.teamId,
            onPersistPhoto = { uri -> viewModel.persistPhoto(uri) },
            onDismiss = { showEditDialog = false },
            onSave = { teamId, name, role, batStyle, bowlStyle, jersey, photoUri ->
                viewModel.updatePlayer(
                    player.copy(
                        teamId = teamId,
                        name = name.trim(),
                        role = role,
                        battingStyle = batStyle,
                        bowlingStyle = bowlStyle,
                        jerseyNumber = jersey,
                        photoUri = photoUri
                    )
                )
                showEditDialog = false
            }
        )
    }
}

@Composable
private fun ProfileStatTile(
    label: String,
    value: String,
    highlight: Boolean = false
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            color = if (highlight) GoldBright else SilverBright,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            color = SilverMid,
            fontSize = 11.sp
        )
    }
}
