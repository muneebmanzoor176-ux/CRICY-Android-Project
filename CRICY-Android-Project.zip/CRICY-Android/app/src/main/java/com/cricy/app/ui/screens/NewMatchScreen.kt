package com.cricy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import com.cricy.app.domain.model.MatchFormat
import com.cricy.app.ui.components.CricyTopBar
import com.cricy.app.ui.components.GoldHighlightButton
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.components.PlayerAvatar
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurfaceBorder
import com.cricy.app.ui.theme.CricySurfaceElevated
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.theme.SilverPrimary
import com.cricy.app.ui.theme.WicketCrimson
import com.cricy.app.ui.viewmodel.NewMatchViewModel

@Composable
fun NewMatchScreen(
    viewModel: NewMatchViewModel,
    onBack: () -> Unit,
    onManageTeams: () -> Unit,
    onMatchCreated: (Long) -> Unit
) {
    val teams by viewModel.teams.collectAsState()
    val players by viewModel.players.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var selectedFormat by remember { mutableStateOf(MatchFormat.fromString(settings.defaultFormat)) }
    var customOversText by remember { mutableStateOf(settings.defaultCustomOvers.toString()) }

    var teamAId by remember { mutableStateOf<Long?>(null) }
    var teamBId by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(teams) {
        if (teamAId == null && teams.isNotEmpty()) teamAId = teams[0].id
        if (teamBId == null && teams.size > 1) teamBId = teams[1].id
    }

    val teamA = teams.firstOrNull { it.id == teamAId }
    val teamB = teams.firstOrNull { it.id == teamBId }

    val teamAPlayers = remember(players, teamAId) { players.filter { it.teamId == teamAId } }
    val teamBPlayers = remember(players, teamBId) { players.filter { it.teamId == teamBId } }

    var teamASquad by remember(teamAId, teamAPlayers) {
        mutableStateOf(teamAPlayers.take(11).map { it.id }.toSet())
    }
    var teamBSquad by remember(teamBId, teamBPlayers) {
        mutableStateOf(teamBPlayers.take(11).map { it.id }.toSet())
    }

    var tossWinnerId by remember(teamAId, teamBId) { mutableStateOf(teamAId) }
    var tossDecision by remember { mutableStateOf("BAT") }

    val battingFirstTeamId = remember(tossWinnerId, tossDecision, teamAId, teamBId) {
        if (tossDecision == "BAT") tossWinnerId else if (tossWinnerId == teamAId) teamBId else teamAId
    }
    val bowlingFirstTeamId = remember(battingFirstTeamId, teamAId, teamBId) {
        if (battingFirstTeamId == teamAId) teamBId else teamAId
    }

    val battingFirstSquad = remember(battingFirstTeamId, teamAId, teamAPlayers, teamBPlayers, teamASquad, teamBSquad) {
        if (battingFirstTeamId == teamAId) {
            teamAPlayers.filter { it.id in teamASquad }
        } else {
            teamBPlayers.filter { it.id in teamBSquad }
        }
    }
    val bowlingFirstSquad = remember(bowlingFirstTeamId, teamAId, teamAPlayers, teamBPlayers, teamASquad, teamBSquad) {
        if (bowlingFirstTeamId == teamAId) {
            teamAPlayers.filter { it.id in teamASquad }
        } else {
            teamBPlayers.filter { it.id in teamBSquad }
        }
    }

    var strikerId by remember(battingFirstSquad) { mutableStateOf(battingFirstSquad.getOrNull(0)?.id) }
    var nonStrikerId by remember(battingFirstSquad) { mutableStateOf(battingFirstSquad.getOrNull(1)?.id) }
    var bowlerId by remember(bowlingFirstSquad) { mutableStateOf(bowlingFirstSquad.lastOrNull()?.id) }

    val oversLimit = when (selectedFormat) {
        MatchFormat.T20 -> 20
        MatchFormat.ODI -> 50
        MatchFormat.CUSTOM -> (customOversText.toIntOrNull() ?: 10).coerceIn(1, 99)
    }

    val validationError = when {
        teams.size < 2 -> "Create at least 2 teams with players first."
        teamA == null || teamB == null || teamA.id == teamB.id -> "Select two different teams."
        teamASquad.size < 2 -> "${teamA.name} needs at least 2 selected players."
        teamBSquad.size < 2 -> "${teamB.name} needs at least 2 selected players."
        strikerId == null || nonStrikerId == null || strikerId == nonStrikerId -> "Select two distinct opening batters."
        bowlerId == null -> "Select an opening bowler."
        else -> null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding()
    ) {
        CricyTopBar(
            title = "New Match",
            subtitle = "FORMAT, SQUADS & TOSS",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Format selection
            item {
                MetallicCard {
                    Text(
                        text = "MATCH FORMAT",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FormatChip(
                            label = "T20 (20)",
                            selected = selectedFormat == MatchFormat.T20,
                            onClick = { selectedFormat = MatchFormat.T20 },
                            modifier = Modifier.weight(1f)
                        )
                        FormatChip(
                            label = "ODI (50)",
                            selected = selectedFormat == MatchFormat.ODI,
                            onClick = { selectedFormat = MatchFormat.ODI },
                            modifier = Modifier.weight(1f)
                        )
                        FormatChip(
                            label = "Custom",
                            selected = selectedFormat == MatchFormat.CUSTOM,
                            onClick = { selectedFormat = MatchFormat.CUSTOM },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (selectedFormat == MatchFormat.CUSTOM) {
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = customOversText,
                            onValueChange = { input ->
                                customOversText = input.filter { it.isDigit() }.take(2)
                            },
                            label = { Text("Overs per innings (1-99)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = CricySurfaceBorder,
                                focusedTextColor = SilverBright,
                                unfocusedTextColor = SilverBright,
                                focusedLabelColor = GoldBright,
                                unfocusedLabelColor = SilverMid
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // 2. Team selection
            item {
                MetallicCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SELECT TEAMS",
                            color = GoldPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = "Manage Teams",
                            color = SilverPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable(onClick = onManageTeams)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    TeamDropdown(
                        label = "Team A",
                        teams = teams,
                        selectedTeam = teamA,
                        onSelected = { teamAId = it.id }
                    )
                    Spacer(Modifier.height(10.dp))
                    TeamDropdown(
                        label = "Team B",
                        teams = teams,
                        selectedTeam = teamB,
                        onSelected = { teamBId = it.id }
                    )
                }
            }

            // 3. Squad selection
            if (teamA != null && teamB != null) {
                item {
                    SquadSelectorCard(
                        team = teamA,
                        players = teamAPlayers,
                        selectedIds = teamASquad,
                        onToggle = { pid ->
                            teamASquad = if (pid in teamASquad) teamASquad - pid else teamASquad + pid
                        }
                    )
                }
                item {
                    SquadSelectorCard(
                        team = teamB,
                        players = teamBPlayers,
                        selectedIds = teamBSquad,
                        onToggle = { pid ->
                            teamBSquad = if (pid in teamBSquad) teamBSquad - pid else teamBSquad + pid
                        }
                    )
                }
            }

            // 4. Toss
            if (teamA != null && teamB != null) {
                item {
                    MetallicCard(goldHighlight = true) {
                        Text(
                            text = "TOSS & BATTING ORDER",
                            color = GoldPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("Toss Winner", color = SilverMid, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FormatChip(
                                label = teamA.shortName,
                                selected = tossWinnerId == teamA.id,
                                onClick = { tossWinnerId = teamA.id },
                                modifier = Modifier.weight(1f)
                            )
                            FormatChip(
                                label = teamB.shortName,
                                selected = tossWinnerId == teamB.id,
                                onClick = { tossWinnerId = teamB.id },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(Modifier.height(10.dp))
                        Text("Elected To", color = SilverMid, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FormatChip(
                                label = "Bat First",
                                selected = tossDecision == "BAT",
                                onClick = { tossDecision = "BAT" },
                                modifier = Modifier.weight(1f)
                            )
                            FormatChip(
                                label = "Bowl First",
                                selected = tossDecision == "BOWL",
                                onClick = { tossDecision = "BOWL" },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 5. Opening Batters & Bowler
            if (battingFirstSquad.size >= 2 && bowlingFirstSquad.isNotEmpty()) {
                item {
                    MetallicCard {
                        Text(
                            text = "OPENING LINEUP",
                            color = GoldPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        PlayerDropdown(
                            label = "Opening Striker",
                            players = battingFirstSquad,
                            selected = battingFirstSquad.firstOrNull { it.id == strikerId },
                            onSelected = {
                                if (it.id == nonStrikerId) nonStrikerId = strikerId
                                strikerId = it.id
                            }
                        )
                        Spacer(Modifier.height(10.dp))
                        PlayerDropdown(
                            label = "Opening Non-Striker",
                            players = battingFirstSquad.filter { it.id != strikerId },
                            selected = battingFirstSquad.firstOrNull { it.id == nonStrikerId },
                            onSelected = { nonStrikerId = it.id }
                        )
                        Spacer(Modifier.height(10.dp))
                        PlayerDropdown(
                            label = "Opening Bowler",
                            players = bowlingFirstSquad,
                            selected = bowlingFirstSquad.firstOrNull { it.id == bowlerId },
                            onSelected = { bowlerId = it.id }
                        )
                    }
                }
            }

            if (validationError != null) {
                item {
                    Text(
                        text = validationError,
                        color = WicketCrimson,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            GoldHighlightButton(
                text = "Start $oversLimit-Over Match",
                icon = Icons.Default.PlayArrow,
                enabled = validationError == null,
                onClick = {
                    if (teamA != null && teamB != null && tossWinnerId != null &&
                        strikerId != null && nonStrikerId != null && bowlerId != null
                    ) {
                        viewModel.createAndStartMatch(
                            format = selectedFormat.name,
                            oversLimit = oversLimit,
                            teamAId = teamA.id,
                            teamBId = teamB.id,
                            teamASquadIds = teamASquad.toList(),
                            teamBSquadIds = teamBSquad.toList(),
                            tossWinnerTeamId = tossWinnerId!!,
                            tossDecision = tossDecision,
                            strikerId = strikerId!!,
                            nonStrikerId = nonStrikerId!!,
                            bowlerId = bowlerId!!,
                            onCreated = onMatchCreated
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun FormatChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) GoldPrimary.copy(alpha = 0.2f) else CricySurfaceElevated)
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) GoldBright else CricySurfaceBorder,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) GoldBright else SilverBright,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TeamDropdown(
    label: String,
    teams: List<TeamEntity>,
    selectedTeam: TeamEntity?,
    onSelected: (TeamEntity) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selectedTeam?.let { "${it.name} (${it.shortName})" } ?: "Select Team",
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = CricySurfaceBorder,
                focusedTextColor = SilverBright,
                unfocusedTextColor = SilverBright,
                focusedLabelColor = GoldBright,
                unfocusedLabelColor = SilverMid
            ),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(CricySurfaceElevated)
        ) {
            teams.forEach { team ->
                DropdownMenuItem(
                    text = { Text("${team.name} (${team.shortName})", color = SilverBright) },
                    onClick = {
                        onSelected(team)
                        expanded = false
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlayerDropdown(
    label: String,
    players: List<PlayerEntity>,
    selected: PlayerEntity?,
    onSelected: (PlayerEntity) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selected?.name ?: "Select Player",
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = CricySurfaceBorder,
                focusedTextColor = SilverBright,
                unfocusedTextColor = SilverBright,
                focusedLabelColor = GoldBright,
                unfocusedLabelColor = SilverMid
            ),
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(CricySurfaceElevated)
        ) {
            players.forEach { player ->
                DropdownMenuItem(
                    text = { Text("${player.name} (${player.role})", color = SilverBright) },
                    onClick = {
                        onSelected(player)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun SquadSelectorCard(
    team: TeamEntity,
    players: List<PlayerEntity>,
    selectedIds: Set<Long>,
    onToggle: (Long) -> Unit
) {
    MetallicCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${team.name.uppercase()} SQUAD",
                color = GoldPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Text(
                text = "${selectedIds.size} selected",
                color = SilverPrimary,
                fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(8.dp))
        if (players.isEmpty()) {
            Text(
                text = "No players in this team yet. Add players in My Players.",
                color = SilverMid,
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            players.forEach { player ->
                val checked = player.id in selectedIds
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onToggle(player.id) }
                        .padding(vertical = 6.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PlayerAvatar(name = player.name, photoUri = player.photoUri, size = 34.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = player.name,
                            color = SilverBright,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = player.role.replace("_", " "),
                            color = SilverMid,
                            fontSize = 11.sp
                        )
                    }
                    Checkbox(
                        checked = checked,
                        onCheckedChange = { onToggle(player.id) },
                        colors = CheckboxDefaults.colors(
                            checkedColor = GoldPrimary,
                            uncheckedColor = SilverMid,
                            checkmarkColor = CricyBlack
                        )
                    )
                }
            }
        }
    }
}
