package com.cricy.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val CricyDarkColorScheme = darkColorScheme(
    primary = SilverPrimary,
    onPrimary = CricyBlack,
    secondary = GoldPrimary,
    onSecondary = CricyBlack,
    tertiary = GoldBright,
    background = CricyBlack,
    onBackground = SilverBright,
    surface = CricySurface,
    onSurface = SilverBright,
    surfaceVariant = CricySurfaceElevated,
    onSurfaceVariant = SilverMid,
    outline = CricySurfaceBorder,
    error = WicketCrimson,
    onError = SilverBright
)

@Composable
fun CricyTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.setDecorFitsSystemWindows(window, false)
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = false
                insetsController.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = CricyDarkColorScheme,
        typography = CricyTypography,
        content = content
    )
}
