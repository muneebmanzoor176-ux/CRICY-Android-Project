package com.cricy.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "teams")
data class TeamEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val shortName: String,
    val accentHex: String = "#C8CED6",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "players",
    foreignKeys = [
        ForeignKey(
            entity = TeamEntity::class,
            parentColumns = ["id"],
            childColumns = ["teamId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("teamId")]
)
data class PlayerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val teamId: Long,
    val name: String,
    val role: String = "ALL_ROUNDER", // BATTER, BOWLER, ALL_ROUNDER, WICKET_KEEPER
    val battingStyle: String = "Right-Hand Bat",
    val bowlingStyle: String = "Right-Arm Medium",
    val jerseyNumber: Int = 0,
    val photoUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "matches",
    indices = [Index("teamAId"), Index("teamBId"), Index("status")]
)
data class MatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val format: String, // T20, ODI, CUSTOM
    val oversLimit: Int,
    val teamAId: Long,
    val teamBId: Long,
    val teamASquadIdsCsv: String, // Comma-separated player IDs playing for Team A
    val teamBSquadIdsCsv: String, // Comma-separated player IDs playing for Team B
    val tossWinnerTeamId: Long,
    val tossDecision: String, // BAT, BOWL
    val battingFirstTeamId: Long,
    val currentInnings: Int = 1, // 1 or 2
    val status: String = "IN_PROGRESS", // IN_PROGRESS, INNINGS_BREAK, COMPLETED
    val targetRuns: Int? = null,
    val winnerTeamId: Long? = null,
    val resultSummary: String = "",
    val innings1StrikerId: Long? = null,
    val innings1NonStrikerId: Long? = null,
    val innings1BowlerId: Long? = null,
    val innings2StrikerId: Long? = null,
    val innings2NonStrikerId: Long? = null,
    val innings2BowlerId: Long? = null,
    val activeStrikerId: Long? = null,
    val activeNonStrikerId: Long? = null,
    val activeBowlerId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "deliveries",
    foreignKeys = [
        ForeignKey(
            entity = MatchEntity::class,
            parentColumns = ["id"],
            childColumns = ["matchId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("matchId"), Index("strikerId"), Index("bowlerId"), Index("dismissedPlayerId")]
)
data class DeliveryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val matchId: Long,
    val inningsNumber: Int,
    val sequenceNumber: Int,
    val overNumber: Int, // 0-indexed over number
    val ballInOver: Int, // 1..6 for legal balls, 0 if extra re-ball
    val strikerId: Long,
    val nonStrikerId: Long,
    val bowlerId: Long,
    val runsOffBat: Int = 0,
    val extraType: String = "NONE", // NONE, WIDE, NO_BALL, BYE, LEG_BYE
    val extraRuns: Int = 0,
    val isWicket: Boolean = false,
    val wicketType: String = "NONE", // NONE, BOWLED, CAUGHT, LBW, RUN_OUT, STUMPED, HIT_WICKET
    val dismissedPlayerId: Long? = null,
    val fielderId: Long? = null,
    val countsAsLegalBall: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
