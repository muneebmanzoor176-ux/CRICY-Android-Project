package com.cricy.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.domain.model.ScoringCelebration
import com.cricy.app.ui.theme.BoundaryBlue
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.WicketCrimson
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ScoringCelebrationOverlay(
    celebration: ScoringCelebration,
    enabled: Boolean
) {
    val visible = enabled && (
        celebration == ScoringCelebration.FOUR ||
            celebration == ScoringCelebration.SIX ||
            celebration == ScoringCelebration.WICKET
        )

    val burstProgress = remember(celebration) { Animatable(0f) }
    LaunchedEffect(celebration, visible) {
        if (visible) {
            burstProgress.snapTo(0f)
            burstProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 850, easing = FastOutSlowInEasing)
            )
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(140)) + scaleIn(initialScale = 0.72f, animationSpec = tween(220)),
        exit = fadeOut(tween(240)) + scaleOut(targetScale = 1.08f, animationSpec = tween(240))
    ) {
        val (title, subtitle, accent, glowColor) = when (celebration) {
            ScoringCelebration.FOUR -> CelebrationMeta(
                "FOUR!",
                "BOUNDARY",
                BoundaryBlue,
                BoundaryBlue.copy(alpha = 0.45f)
            )
            ScoringCelebration.SIX -> CelebrationMeta(
                "MAXIMUM 6!",
                "CLEAN STRIKE",
                GoldBright,
                GoldPrimary.copy(alpha = 0.55f)
            )
            ScoringCelebration.WICKET -> CelebrationMeta(
                "WICKET!",
                "OUT!",
                WicketCrimson,
                WicketCrimson.copy(alpha = 0.55f)
            )
            else -> CelebrationMeta("", "", SilverBright, Color.Transparent)
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CricyBlack.copy(alpha = 0.55f)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val maxRadius = size.minDimension * 0.44f * burstProgress.value
                val particleAlpha = (1f - burstProgress.value).coerceIn(0f, 1f)

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glowColor.copy(alpha = particleAlpha * 0.5f), Color.Transparent),
                        center = center,
                        radius = (maxRadius + 120f)
                    ),
                    radius = maxRadius + 120f,
                    center = center
                )

                val rays = 12
                for (i in 0 until rays) {
                    val angle = (i * (360f / rays)) * (Math.PI / 180.0)
                    val x = center.x + (maxRadius * cos(angle)).toFloat()
                    val y = center.y + (maxRadius * sin(angle)).toFloat()
                    drawCircle(
                        color = accent.copy(alpha = particleAlpha),
                        radius = 5.dp.toPx() * (1f - burstProgress.value * 0.5f),
                        center = Offset(x, y)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .background(
                        color = Color(0xFF0E121A),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .border(2.dp, accent, RoundedCornerShape(20.dp))
                    .padding(horizontal = 36.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = subtitle,
                    color = accent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.5.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = title,
                    color = SilverBright,
                    fontSize = 36.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

private data class CelebrationMeta(
    val title: String,
    val subtitle: String,
    val accent: Color,
    val glow: Color
)
