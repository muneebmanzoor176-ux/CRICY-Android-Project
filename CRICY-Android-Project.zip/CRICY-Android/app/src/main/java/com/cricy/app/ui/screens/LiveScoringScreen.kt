package com.cricy.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.domain.model.ExtraType
import com.cricy.app.domain.model.MatchLiveState
import com.cricy.app.domain.model.WicketType
import com.cricy.app.ui.components.GoldHighlightButton
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.components.MetallicSilverButton
import com.cricy.app.ui.components.PlayerAvatar
import com.cricy.app.ui.components.ScoringCelebrationOverlay
import com.cricy.app.ui.theme.BoundaryBlue
import com.cricy.app.ui.theme.BoundaryBlueDark
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurface
import com.cricy.app.ui.theme.CricySurfaceBorder
import com.cricy.app.ui.theme.CricySurfaceElevated
import com.cricy.app.ui.theme.ExtraAmber
import com.cricy.app.ui.theme.ExtraAmberDark
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldButtonBrush
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverButtonBrush
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.theme.SilverPrimary
import com.cricy.app.ui.theme.WicketCrimson
import com.cricy.app.ui.theme.WicketCrimsonDark
import com.cricy.app.ui.theme.WinEmerald
import com.cricy.app.ui.viewmodel.LiveScoringViewModel
import java.util.Locale

@Composable
fun LiveScoringScreen(
    viewModel: LiveScoringViewModel,
    onBack: () -> Unit,
    onOpenScorecard: (Long) -> Unit
) {
    val state by viewModel.liveState.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val celebration by viewModel.celebration.collectAsState()
    val haptic = LocalHapticFeedback.current

    var pendingExtraModal by remember { mutableStateOf<ExtraType?>(null) }
    var showWicketModal by remember { mutableStateOf(false) }
    var showUndoConfirm by remember { mutableStateOf(false) }
    var showEndInningsConfirm by remember { mutableStateOf(false) }

    fun triggerHaptic() {
        if (settings.hapticFeedbackEnabled) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }

    val currentState = state
    if (currentState == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CricyBlack)
                .systemBarsPadding(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = GoldPrimary)
        }
        return
    }

    val active = currentState.activeInnings
    val strikerStats = active.batters.firstOrNull { it.player.id == active.strikerId }
    val nonStrikerStats = active.batters.firstOrNull { it.player.id == active.nonStrikerId }
    val bowlerStats = active.bowlers.firstOrNull { it.player.id == active.currentBowlerId }
    val activePartnership = active.partnerships.lastOrNull { it.isActive }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Compact Top Broadcast Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(CricySurfaceElevated)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = SilverBright)
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${currentState.teamA.shortName} vs ${currentState.teamB.shortName}",
                        color = SilverBright,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${currentState.match.format} · INNINGS ${active.inningsNumber}",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
                IconButton(onClick = { showEndInningsConfirm = true }) {
                    Icon(Icons.Default.Flag, contentDescription = "End Innings", tint = SilverMid)
                }
                IconButton(onClick = { onOpenScorecard(currentState.match.id) }) {
                    Icon(Icons.Default.Assessment, contentDescription = "Scorecard", tint = GoldBright)
                }
            }

            // Scrollable Broadcast Scoreboard Area
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Main Broadcast Score Strip
                MetallicCard(
                    goldHighlight = true,
                    contentPadding = PaddingValues(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = active.battingTeam.name.uppercase(),
                                color = GoldBright,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                AnimatedContent(
                                    targetState = "${active.totalRuns}/${active.wickets}",
                                    transitionSpec = {
                                        (slideInVertically { -it / 2 } + fadeIn()) togetherWith
                                            (slideOutVertically { it / 2 } + fadeOut())
                                    },
                                    label = "scoreTicker"
                                ) { scoreText ->
                                    Text(
                                        text = scoreText,
                                        color = SilverBright,
                                        fontSize = 38.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    text = "${active.oversDisplay} / ${active.oversLimit} ov",
                                    color = SilverMid,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "CRR ${String.format(Locale.US, "%.2f", active.currentRunRate)}",
                                color = SilverPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (active.requiredRunRate != null) {
                                Text(
                                    text = "RRR ${String.format(Locale.US, "%.2f", active.requiredRunRate)}",
                                    color = GoldBright,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (active.targetRuns != null && active.requiredRuns != null && !currentState.isMatchCompleted) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Target ${active.targetRuns} · Need ${active.requiredRuns} runs from ${active.remainingBalls} balls",
                            color = GoldBright,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Extras ${active.extras.total} (wd ${active.extras.wides}, nb ${active.extras.noBalls}, b ${active.extras.byes}, lb ${active.extras.legByes})",
                        color = SilverMid,
                        fontSize = 11.sp
                    )
                }

                // Match Result Banner if Completed
                if (currentState.isMatchCompleted) {
                    MetallicCard(goldHighlight = true) {
                        Text(
                            text = "MATCH RESULT",
                            color = GoldBright,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = currentState.resultSummary,
                            color = WinEmerald,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            GoldHighlightButton(
                                text = "Full Scorecard",
                                onClick = { onOpenScorecard(currentState.match.id) },
                                modifier = Modifier.weight(1f)
                            )
                            if (currentState.canUndo) {
                                MetallicSilverButton(
                                    text = "Undo Last",
                                    icon = Icons.AutoMirrored.Filled.Undo,
                                    onClick = { viewModel.undoLastDelivery() },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // Active Batters Card
                MetallicCard(contentPadding = PaddingValues(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BATTERS",
                            color = SilverMid,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(CricySurfaceElevated)
                                .clickable {
                                    triggerHaptic()
                                    viewModel.swapStrike()
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.SwapHoriz,
                                contentDescription = "Swap Strike",
                                tint = GoldBright,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text("Swap Strike", color = GoldBright, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    BatterLineRow(
                        player = currentState.striker,
                        runs = strikerStats?.runs ?: 0,
                        balls = strikerStats?.balls ?: 0,
                        fours = strikerStats?.fours ?: 0,
                        sixes = strikerStats?.sixes ?: 0,
                        strikeRate = strikerStats?.strikeRate ?: 0.0,
                        isStriker = true
                    )
                    Spacer(Modifier.height(8.dp))
                    BatterLineRow(
                        player = currentState.nonStriker,
                        runs = nonStrikerStats?.runs ?: 0,
                        balls = nonStrikerStats?.balls ?: 0,
                        fours = nonStrikerStats?.fours ?: 0,
                        sixes = nonStrikerStats?.sixes ?: 0,
                        strikeRate = nonStrikerStats?.strikeRate ?: 0.0,
                        isStriker = false
                    )
                    if (activePartnership != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Partnership: ${activePartnership.runs} (${activePartnership.balls} balls)",
                            color = SilverMid,
                            fontSize = 11.sp
                        )
                    }
                }

                // Active Bowler & This Over Chips
                MetallicCard(contentPadding = PaddingValues(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val bowler = currentState.currentBowler
                        if (bowler != null) {
                            PlayerAvatar(name = bowler.name, photoUri = bowler.photoUri, size = 34.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = bowler.name,
                                    color = SilverBright,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${bowlerStats?.oversDisplay ?: "0.0"}-${bowlerStats?.maidens ?: 0}-${bowlerStats?.runsConceded ?: 0}-${bowlerStats?.wickets ?: 0} · Econ ${String.format(Locale.US, "%.2f", bowlerStats?.economy ?: 0.0)}",
                                    color = GoldPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        } else {
                            Text(
                                text = "Select bowler for next over",
                                color = GoldBright,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("THIS OVER:", color = SilverMid, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        if (active.currentOverChips.isEmpty()) {
                            Text("Ready for ball 1", color = SilverMid, fontSize = 12.sp)
                        } else {
                            active.currentOverChips.forEach { chip ->
                                val bg = when {
                                    chip.isWicket -> WicketCrimsonDark
                                    chip.isBoundarySix -> GoldPrimary.copy(alpha = 0.25f)
                                    chip.isBoundaryFour -> BoundaryBlueDark
                                    chip.isExtra -> ExtraAmberDark
                                    else -> CricySurfaceElevated
                                }
                                val border = when {
                                    chip.isWicket -> WicketCrimson
                                    chip.isBoundarySix -> GoldBright
                                    chip.isBoundaryFour -> BoundaryBlue
                                    chip.isExtra -> ExtraAmber
                                    else -> CricySurfaceBorder
                                }
                                val fg = when {
                                    chip.isWicket -> WicketCrimson
                                    chip.isBoundarySix -> GoldBright
                                    chip.isBoundaryFour -> BoundaryBlue
                                    chip.isExtra -> ExtraAmber
                                    else -> SilverBright
                                }
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(bg)
                                        .border(1.dp, border, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = chip.label,
                                        color = fg,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                // Recent Fall of Wicket Info
                if (active.fallOfWickets.isNotEmpty()) {
                    val lastFow = active.fallOfWickets.last()
                    Text(
                        text = "Last Wicket: ${lastFow.batterName} (${lastFow.dismissalText}) · ${lastFow.scoreAtFall}/${lastFow.wicketNumber} (${lastFow.overAtFall} ov)",
                        color = SilverMid,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }

            // Bottom One-Handed Thumb Scoring Keypad
            if (!currentState.isMatchCompleted) {
                val keypadEnabled = !currentState.needsNextBatter &&
                    !currentState.needsNextBowler &&
                    !currentState.needsSecondInningsOpeners

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CricySurface)
                        .border(1.dp, CricySurfaceBorder, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Row 1: 0, 1, 2, 3
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(0, 1, 2, 3).forEach { run ->
                            ScorePadButton(
                                label = run.toString(),
                                enabled = keypadEnabled,
                                onClick = {
                                    triggerHaptic()
                                    viewModel.recordDelivery(runsOffBat = run)
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Row 2: 4, 6, WICKET
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ScorePadButton(
                            label = "4",
                            subLabel = "FOUR",
                            enabled = keypadEnabled,
                            accentBrush = Brush.verticalGradient(listOf(BoundaryBlueDark, Color(0xFF0A1B2E))),
                            borderColor = BoundaryBlue,
                            textColor = BoundaryBlue,
                            onClick = {
                                triggerHaptic()
                                viewModel.recordDelivery(runsOffBat = 4)
                            },
                            modifier = Modifier.weight(1f)
                        )
                        ScorePadButton(
                            label = "6",
                            subLabel = "SIX",
                            enabled = keypadEnabled,
                            accentBrush = GoldButtonBrush,
                            borderColor = GoldBright,
                            textColor = CricyBlack,
                            onClick = {
                                triggerHaptic()
                                viewModel.recordDelivery(runsOffBat = 6)
                            },
                            modifier = Modifier.weight(1f)
                        )
                        ScorePadButton(
                            label = "WICKET",
                            enabled = keypadEnabled,
                            accentBrush = Brush.verticalGradient(listOf(WicketCrimsonDark, Color(0xFF280809))),
                            borderColor = WicketCrimson,
                            textColor = WicketCrimson,
                            onClick = {
                                triggerHaptic()
                                showWicketModal = true
                            },
                            modifier = Modifier.weight(1.25f)
                        )
                    }

                    // Row 3: WIDE, NO BALL, BYE, LEG BYE
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            ExtraType.WIDE to "WIDE",
                            ExtraType.NO_BALL to "NO BALL",
                            ExtraType.BYE to "BYE",
                            ExtraType.LEG_BYE to "LEG BYE"
                        ).forEach { (type, label) ->
                            ScorePadButton(
                                label = label,
                                compact = true,
                                enabled = keypadEnabled,
                                borderColor = ExtraAmber.copy(alpha = 0.7f),
                                textColor = ExtraAmber,
                                onClick = {
                                    triggerHaptic()
                                    pendingExtraModal = type
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Row 4: UNDO
                    MetallicSilverButton(
                        text = "UNDO PREVIOUS DELIVERY",
                        icon = Icons.AutoMirrored.Filled.Undo,
                        enabled = currentState.canUndo,
                        onClick = {
                            triggerHaptic()
                            if (settings.confirmUndoEnabled) {
                                showUndoConfirm = true
                            } else {
                                viewModel.undoLastDelivery()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Celebration Animation Overlay (4, 6, Wicket)
        ScoringCelebrationOverlay(
            celebration = celebration,
            enabled = settings.celebrationAnimationsEnabled
        )
    }

    // Extra Runs Dialog (Wide, No Ball, Bye, Leg Bye)
    pendingExtraModal?.let { extraType ->
        ExtraDeliveryDialog(
            extraType = extraType,
            onDismiss = { pendingExtraModal = null },
            onConfirm = { batRuns, extraRuns ->
                viewModel.recordDelivery(
                    runsOffBat = batRuns,
                    extraType = extraType,
                    extraRuns = extraRuns
                )
                pendingExtraModal = null
            }
        )
    }

    // Wicket Dialog
    if (showWicketModal) {
        val bowlingSquad = if (active.bowlingTeam.id == currentState.teamA.id) {
            currentState.teamASquad
        } else {
            currentState.teamBSquad
        }
        WicketDialog(
            striker = currentState.striker,
            nonStriker = currentState.nonStriker,
            fielders = bowlingSquad,
            onDismiss = { showWicketModal = false },
            onConfirm = { wicketType, dismissedId, fielderId, runsCompleted ->
                viewModel.recordDelivery(
                    runsOffBat = runsCompleted,
                    extraType = ExtraType.NONE,
                    extraRuns = 0,
                    isWicket = true,
                    wicketType = wicketType,
                    dismissedPlayerId = dismissedId,
                    fielderId = fielderId
                )
                showWicketModal = false
            }
        )
    }

    // Next Batter Dialog (after wicket)
    if (currentState.needsNextBatter) {
        PlayerSelectionDialog(
            title = "Select Next Batter",
            subtitle = "Choose incoming batter to take crease",
            players = currentState.availableNextBatters,
            onSelect = { viewModel.selectNextBatter(it.id) }
        )
    }

    // Next Bowler Dialog (after over completion, only when batter selection is complete)
    if (!currentState.needsNextBatter && currentState.needsNextBowler) {
        PlayerSelectionDialog(
            title = "Over Complete · Next Bowler",
            subtitle = "Choose bowler for over ${(active.legalBalls / 6) + 1}",
            players = currentState.availableNextBowlers,
            onSelect = { viewModel.selectNextBowler(it.id) }
        )
    }

    // Innings Break Dialog -> Select 2nd Innings Openers & Bowler
    if (currentState.needsSecondInningsOpeners) {
        SecondInningsOpenersDialog(
            state = currentState,
            onStartSecondInnings = { s, ns, b ->
                viewModel.startSecondInnings(s, ns, b)
            }
        )
    }

    if (showUndoConfirm) {
        AlertDialog(
            onDismissRequest = { showUndoConfirm = false },
            containerColor = CricySurface,
            title = { Text("Undo Delivery?", color = SilverBright, fontWeight = FontWeight.Bold) },
            text = { Text("Remove the most recent ball and recalculate the scoreboard?", color = SilverMid) },
            confirmButton = {
                GoldHighlightButton(
                    text = "Undo",
                    onClick = {
                        viewModel.undoLastDelivery()
                        showUndoConfirm = false
                    },
                    modifier = Modifier.width(100.dp)
                )
            },
            dismissButton = {
                TextButton(onClick = { showUndoConfirm = false }) {
                    Text("Cancel", color = SilverMid)
                }
            }
        )
    }

    if (showEndInningsConfirm) {
        AlertDialog(
            onDismissRequest = { showEndInningsConfirm = false },
            containerColor = CricySurface,
            title = { Text("End Current Innings?", color = SilverBright, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    text = if (active.inningsNumber == 1) {
                        "Close Innings 1 at ${active.totalRuns}/${active.wickets} and set target ${active.totalRuns + 1}?"
                    } else {
                        "Conclude the match now and calculate the result?"
                    },
                    color = SilverMid
                )
            },
            confirmButton = {
                GoldHighlightButton(
                    text = "Confirm",
                    onClick = {
                        viewModel.endCurrentInningsManually()
                        showEndInningsConfirm = false
                    },
                    modifier = Modifier.width(110.dp)
                )
            },
            dismissButton = {
                TextButton(onClick = { showEndInningsConfirm = false }) {
                    Text("Cancel", color = SilverMid)
                }
            }
        )
    }
}

@Composable
private fun BatterLineRow(
    player: PlayerEntity?,
    runs: Int,
    balls: Int,
    fours: Int,
    sixes: Int,
    strikeRate: Double,
    isStriker: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (player != null) {
            PlayerAvatar(name = player.name, photoUri = player.photoUri, size = 32.dp, goldRing = isStriker)
            Spacer(Modifier.width(8.dp))
            Text(
                text = if (isStriker) "${player.name} *" else player.name,
                color = if (isStriker) GoldBright else SilverBright,
                fontWeight = if (isStriker) FontWeight.Bold else FontWeight.Medium,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "$runs($balls)",
                color = SilverBright,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = "4s:$fours  6s:$sixes  SR:${String.format(Locale.US, "%.0f", strikeRate)}",
                color = SilverMid,
                fontSize = 11.sp
            )
        } else {
            Text(
                text = "Waiting for batter...",
                color = SilverMid,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun ScorePadButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    subLabel: String? = null,
    compact: Boolean = false,
    enabled: Boolean = true,
    accentBrush: Brush = SilverButtonBrush,
    borderColor: Color = SilverPrimary.copy(alpha = 0.4f),
    textColor: Color = SilverBright
) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = modifier
            .height(if (compact) 46.dp else 56.dp)
            .clip(shape)
            .background(if (enabled) accentBrush else Brush.verticalGradient(listOf(CricySurfaceElevated, CricySurfaceElevated)))
            .border(1.dp, if (enabled) borderColor else CricySurfaceBorder, shape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                color = if (enabled) textColor else SilverMid.copy(alpha = 0.4f),
                fontWeight = FontWeight.ExtraBold,
                fontSize = if (compact) 11.sp else 17.sp,
                maxLines = 1
            )
            if (subLabel != null) {
                Text(
                    text = subLabel,
                    color = if (enabled) textColor.copy(alpha = 0.8f) else SilverMid.copy(alpha = 0.3f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
private fun ExtraDeliveryDialog(
    extraType: ExtraType,
    onDismiss: () -> Unit,
    onConfirm: (runsOffBat: Int, extraRuns: Int) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CricySurface,
        title = {
            Text(
                text = "${extraType.label} Runs",
                color = GoldBright,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = when (extraType) {
                        ExtraType.WIDE -> "1 penalty wide + any additional runs crossed:"
                        ExtraType.NO_BALL -> "1 penalty no-ball + runs scored off the bat:"
                        ExtraType.BYE -> "Select bye runs:"
                        ExtraType.LEG_BYE -> "Select leg-bye runs:"
                        ExtraType.NONE -> ""
                    },
                    color = SilverMid,
                    fontSize = 13.sp
                )
                val options = when (extraType) {
                    ExtraType.WIDE -> listOf(0, 1, 2, 3, 4)
                    ExtraType.NO_BALL -> listOf(0, 1, 2, 3, 4, 6)
                    ExtraType.BYE, ExtraType.LEG_BYE -> listOf(1, 2, 3, 4)
                    ExtraType.NONE -> listOf(0)
                }
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    options.forEach { value ->
                        val chipTitle = when (extraType) {
                            ExtraType.WIDE -> if (value == 0) "Wd (1)" else "Wd+$value"
                            ExtraType.NO_BALL -> if (value == 0) "NB" else "NB+$value"
                            ExtraType.BYE -> "${value}B"
                            ExtraType.LEG_BYE -> "${value}LB"
                            ExtraType.NONE -> "$value"
                        }
                        OutlinedButton(
                            onClick = {
                                when (extraType) {
                                    ExtraType.WIDE -> onConfirm(0, 1 + value)
                                    ExtraType.NO_BALL -> onConfirm(value, 1)
                                    ExtraType.BYE, ExtraType.LEG_BYE -> onConfirm(0, value)
                                    ExtraType.NONE -> onConfirm(value, 0)
                                }
                            },
                            border = BorderStroke(1.dp, GoldPrimary),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SilverBright)
                        ) {
                            Text(chipTitle, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SilverMid)
            }
        }
    )
}

@Composable
private fun WicketDialog(
    striker: PlayerEntity?,
    nonStriker: PlayerEntity?,
    fielders: List<PlayerEntity>,
    onDismiss: () -> Unit,
    onConfirm: (WicketType, Long, Long?, Int) -> Unit
) {
    var selectedType by remember { mutableStateOf(WicketType.BOWLED) }
    var dismissedId by remember(striker) { mutableStateOf(striker?.id ?: 0L) }
    var selectedFielderId by remember { mutableStateOf<Long?>(null) }
    var runsCompleted by remember { mutableIntStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CricySurface,
        title = {
            Text("Record Wicket", color = WicketCrimson, fontWeight = FontWeight.ExtraBold)
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Dismissal Type", color = SilverMid, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        WicketType.BOWLED,
                        WicketType.CAUGHT,
                        WicketType.LBW,
                        WicketType.RUN_OUT,
                        WicketType.STUMPED,
                        WicketType.HIT_WICKET
                    ).forEach { wt ->
                        val active = selectedType == wt
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) WicketCrimsonDark else CricySurfaceElevated)
                                .border(1.dp, if (active) WicketCrimson else CricySurfaceBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedType = wt
                                    if (wt != WicketType.RUN_OUT && striker != null) {
                                        dismissedId = striker.id
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 7.dp)
                        ) {
                            Text(wt.label, color = if (active) WicketCrimson else SilverBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (selectedType == WicketType.RUN_OUT && striker != null && nonStriker != null) {
                    Text("Who was Run Out?", color = SilverMid, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(striker, nonStriker).forEach { b ->
                            val active = dismissedId == b.id
                            Surface(
                                onClick = { dismissedId = b.id },
                                color = if (active) GoldPrimary.copy(alpha = 0.2f) else CricySurfaceElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (active) GoldBright else CricySurfaceBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = b.name,
                                    color = if (active) GoldBright else SilverBright,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    }

                    Text("Runs completed before Run Out", color = SilverMid, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0, 1, 2, 3).forEach { r ->
                            val active = runsCompleted == r
                            Surface(
                                onClick = { runsCompleted = r },
                                color = if (active) GoldPrimary.copy(alpha = 0.2f) else CricySurfaceElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (active) GoldBright else CricySurfaceBorder)
                            ) {
                                Text(
                                    text = r.toString(),
                                    color = if (active) GoldBright else SilverBright,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                if (selectedType == WicketType.CAUGHT || selectedType == WicketType.RUN_OUT || selectedType == WicketType.STUMPED) {
                    Text("Fielder / Keeper (Optional)", color = SilverMid, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        fielders.forEach { f ->
                            val active = selectedFielderId == f.id
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) GoldPrimary.copy(alpha = 0.2f) else CricySurfaceElevated)
                                    .border(1.dp, if (active) GoldBright else CricySurfaceBorder, RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedFielderId = if (active) null else f.id
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(f.name, color = if (active) GoldBright else SilverBright, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            GoldHighlightButton(
                text = "Confirm Out",
                onClick = {
                    onConfirm(selectedType, dismissedId, selectedFielderId, runsCompleted)
                },
                modifier = Modifier.width(135.dp)
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SilverMid)
            }
        }
    )
}

@Composable
private fun PlayerSelectionDialog(
    title: String,
    subtitle: String,
    players: List<PlayerEntity>,
    onSelect: (PlayerEntity) -> Unit
) {
    AlertDialog(
        onDismissRequest = {},
        containerColor = CricySurface,
        title = {
            Column {
                Text(title, color = GoldBright, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, color = SilverMid, fontSize = 12.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                players.forEach { player ->
                    MetallicCard(
                        onClick = { onSelect(player) },
                        contentPadding = PaddingValues(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            PlayerAvatar(name = player.name, photoUri = player.photoUri, size = 38.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(player.name, color = SilverBright, fontWeight = FontWeight.SemiBold)
                                Text(player.role.replace("_", " "), color = SilverMid, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {}
    )
}

@Composable
private fun SecondInningsOpenersDialog(
    state: MatchLiveState,
    onStartSecondInnings: (Long, Long, Long) -> Unit
) {
    val chasingSquad = if (state.innings1.bowlingTeam.id == state.teamA.id) state.teamASquad else state.teamBSquad
    val defendingSquad = if (state.innings1.battingTeam.id == state.teamA.id) state.teamASquad else state.teamBSquad

    var strikerId by remember { mutableStateOf(chasingSquad.getOrNull(0)?.id) }
    var nonStrikerId by remember { mutableStateOf(chasingSquad.getOrNull(1)?.id) }
    var bowlerId by remember { mutableStateOf(defendingSquad.lastOrNull()?.id) }

    val target = state.innings1.totalRuns + 1

    AlertDialog(
        onDismissRequest = {},
        containerColor = CricySurface,
        title = {
            Column {
                Text("Innings Break", color = GoldBright, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${state.innings1.battingTeam.name}: ${state.innings1.totalRuns}/${state.innings1.wickets} (${state.innings1.oversDisplay} ov)\nTarget for ${state.innings1.bowlingTeam.name}: $target",
                    color = SilverBright,
                    fontSize = 13.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Select Striker (${state.innings1.bowlingTeam.shortName})", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                chasingSquad.forEach { p ->
                    val selected = strikerId == p.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) GoldPrimary.copy(alpha = 0.2f) else CricySurfaceElevated)
                            .clickable {
                                if (nonStrikerId == p.id) nonStrikerId = strikerId
                                strikerId = p.id
                            }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlayerAvatar(name = p.name, photoUri = p.photoUri, size = 30.dp, goldRing = selected)
                        Spacer(Modifier.width(8.dp))
                        Text(p.name, color = if (selected) GoldBright else SilverBright, fontSize = 13.sp)
                    }
                }

                Text("Select Non-Striker", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                chasingSquad.filter { it.id != strikerId }.forEach { p ->
                    val selected = nonStrikerId == p.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) GoldPrimary.copy(alpha = 0.2f) else CricySurfaceElevated)
                            .clickable { nonStrikerId = p.id }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlayerAvatar(name = p.name, photoUri = p.photoUri, size = 30.dp, goldRing = selected)
                        Spacer(Modifier.width(8.dp))
                        Text(p.name, color = if (selected) GoldBright else SilverBright, fontSize = 13.sp)
                    }
                }

                Text("Opening Bowler (${state.innings1.battingTeam.shortName})", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                defendingSquad.forEach { p ->
                    val selected = bowlerId == p.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) GoldPrimary.copy(alpha = 0.2f) else CricySurfaceElevated)
                            .clickable { bowlerId = p.id }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlayerAvatar(name = p.name, photoUri = p.photoUri, size = 30.dp, goldRing = selected)
                        Spacer(Modifier.width(8.dp))
                        Text(p.name, color = if (selected) GoldBright else SilverBright, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = {
            GoldHighlightButton(
                text = "Start 2nd Innings",
                enabled = strikerId != null && nonStrikerId != null && strikerId != nonStrikerId && bowlerId != null,
                onClick = {
                    onStartSecondInnings(strikerId!!, nonStrikerId!!, bowlerId!!)
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    )
}
