package com.cricy.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.cricy.app.data.local.entity.DeliveryEntity
import com.cricy.app.data.local.entity.MatchEntity
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import com.cricy.app.data.preferences.CricySettings
import com.cricy.app.data.repository.CricyRepository
import com.cricy.app.domain.engine.CricketScoringEngine
import com.cricy.app.domain.model.ExtraType
import com.cricy.app.domain.model.MatchLiveState
import com.cricy.app.domain.model.PlayerCareerStats
import com.cricy.app.domain.model.ScoringCelebration
import com.cricy.app.domain.model.WicketType
import com.cricy.app.domain.stats.PlayerStatsCalculator
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CricyViewModelFactory(
    private val repository: CricyRepository,
    private val paramId: Long = 0L
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(repository) as T
            modelClass.isAssignableFrom(NewMatchViewModel::class.java) -> NewMatchViewModel(repository) as T
            modelClass.isAssignableFrom(LiveScoringViewModel::class.java) -> LiveScoringViewModel(repository, paramId) as T
            modelClass.isAssignableFrom(TeamsAndPlayersViewModel::class.java) -> TeamsAndPlayersViewModel(repository) as T
            modelClass.isAssignableFrom(StatisticsViewModel::class.java) -> StatisticsViewModel(repository) as T
            modelClass.isAssignableFrom(PlayerProfileViewModel::class.java) -> PlayerProfileViewModel(repository, paramId) as T
            modelClass.isAssignableFrom(MatchHistoryViewModel::class.java) -> MatchHistoryViewModel(repository) as T
            modelClass.isAssignableFrom(ScorecardViewModel::class.java) -> ScorecardViewModel(repository, paramId) as T
            modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(repository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}

data class HomeUiState(
    val unfinishedMatches: List<MatchSummaryItem> = emptyList(),
    val totalMatchesCount: Int = 0,
    val teamsCount: Int = 0,
    val playersCount: Int = 0,
    val settings: CricySettings = CricySettings()
)

data class MatchSummaryItem(
    val match: MatchEntity,
    val teamA: TeamEntity?,
    val teamB: TeamEntity?,
    val liveScoreLine: String
)

class HomeViewModel(private val repository: CricyRepository) : ViewModel() {
    val uiState: StateFlow<HomeUiState> = combine(
        repository.observeAllMatches(),
        repository.observeAllTeams(),
        repository.observeAllPlayers(),
        repository.observeAllDeliveries(),
        repository.settingsFlow
    ) { matches, teams, players, deliveries, settings ->
        val teamMap = teams.associateBy { it.id }
        val deliveriesByMatch = deliveries.groupBy { it.matchId }

        val unfinished = matches
            .filter { it.status != "COMPLETED" }
            .map { m ->
                val tA = teamMap[m.teamAId]
                val tB = teamMap[m.teamBId]
                val scoreLine = if (tA != null && tB != null) {
                    val live = CricketScoringEngine.buildLiveState(
                        match = m,
                        deliveries = deliveriesByMatch[m.id].orEmpty(),
                        teamA = tA,
                        teamB = tB,
                        allPlayers = players
                    )
                    "${live.activeInnings.battingTeam.shortName} ${live.activeInnings.totalRuns}/${live.activeInnings.wickets} (${live.activeInnings.oversDisplay}/${m.oversLimit})"
                } else {
                    "In Progress"
                }
                MatchSummaryItem(match = m, teamA = tA, teamB = tB, liveScoreLine = scoreLine)
            }

        HomeUiState(
            unfinishedMatches = unfinished,
            totalMatchesCount = matches.size,
            teamsCount = teams.size,
            playersCount = players.size,
            settings = settings
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())
}

class NewMatchViewModel(private val repository: CricyRepository) : ViewModel() {
    val teams: StateFlow<List<TeamEntity>> = repository.observeAllTeams()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val players: StateFlow<List<PlayerEntity>> = repository.observeAllPlayers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<CricySettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CricySettings())

    fun createAndStartMatch(
        format: String,
        oversLimit: Int,
        teamAId: Long,
        teamBId: Long,
        teamASquadIds: List<Long>,
        teamBSquadIds: List<Long>,
        tossWinnerTeamId: Long,
        tossDecision: String,
        strikerId: Long,
        nonStrikerId: Long,
        bowlerId: Long,
        onCreated: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val battingFirstId = if (tossDecision == "BAT") {
                tossWinnerTeamId
            } else {
                if (tossWinnerTeamId == teamAId) teamBId else teamAId
            }
            val matchId = repository.createMatch(
                MatchEntity(
                    format = format,
                    oversLimit = oversLimit.coerceIn(1, 99),
                    teamAId = teamAId,
                    teamBId = teamBId,
                    teamASquadIdsCsv = teamASquadIds.joinToString(","),
                    teamBSquadIdsCsv = teamBSquadIds.joinToString(","),
                    tossWinnerTeamId = tossWinnerTeamId,
                    tossDecision = tossDecision,
                    battingFirstTeamId = battingFirstId,
                    currentInnings = 1,
                    status = "IN_PROGRESS",
                    innings1StrikerId = strikerId,
                    innings1NonStrikerId = nonStrikerId,
                    innings1BowlerId = bowlerId,
                    activeStrikerId = strikerId,
                    activeNonStrikerId = nonStrikerId,
                    activeBowlerId = bowlerId
                )
            )
            onCreated(matchId)
        }
    }
}

class LiveScoringViewModel(
    private val repository: CricyRepository,
    private val matchId: Long
) : ViewModel() {

    val settings: StateFlow<CricySettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CricySettings())

    val liveState: StateFlow<MatchLiveState?> = combine(
        repository.observeMatch(matchId),
        repository.observeDeliveriesForMatch(matchId),
        repository.observeAllTeams(),
        repository.observeAllPlayers()
    ) { match, deliveries, teams, players ->
        if (match == null) return@combine null
        val teamA = teams.firstOrNull { it.id == match.teamAId } ?: return@combine null
        val teamB = teams.firstOrNull { it.id == match.teamBId } ?: return@combine null
        CricketScoringEngine.buildLiveState(
            match = match,
            deliveries = deliveries,
            teamA = teamA,
            teamB = teamB,
            allPlayers = players
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _celebration = MutableStateFlow(ScoringCelebration.NONE)
    val celebration: StateFlow<ScoringCelebration> = _celebration.asStateFlow()

    fun recordDelivery(
        runsOffBat: Int,
        extraType: ExtraType = ExtraType.NONE,
        extraRuns: Int = 0,
        isWicket: Boolean = false,
        wicketType: WicketType = WicketType.NONE,
        dismissedPlayerId: Long? = null,
        fielderId: Long? = null
    ) {
        viewModelScope.launch {
            val state = liveState.value ?: return@launch
            if (state.isMatchCompleted || state.needsSecondInningsOpeners) return@launch
            val striker = state.striker ?: return@launch
            val nonStriker = state.nonStriker ?: return@launch
            val bowler = state.currentBowler ?: return@launch

            val countsAsLegalBall = extraType != ExtraType.WIDE && extraType != ExtraType.NO_BALL
            val existingDeliveries = repository.getDeliveriesOnce(matchId)
            val inningsDeliveries = existingDeliveries.filter { it.inningsNumber == state.match.currentInnings }
            val nextSeq = (inningsDeliveries.maxOfOrNull { it.sequenceNumber } ?: 0) + 1
            val currentLegalBalls = state.activeInnings.legalBalls
            val overNumber = currentLegalBalls / 6
            val ballInOver = if (countsAsLegalBall) (currentLegalBalls % 6) + 1 else 0

            val resolvedDismissedId = if (isWicket) dismissedPlayerId ?: striker.id else null

            val delivery = DeliveryEntity(
                matchId = matchId,
                inningsNumber = state.match.currentInnings,
                sequenceNumber = nextSeq,
                overNumber = overNumber,
                ballInOver = ballInOver,
                strikerId = striker.id,
                nonStrikerId = nonStriker.id,
                bowlerId = bowler.id,
                runsOffBat = runsOffBat,
                extraType = extraType.name,
                extraRuns = extraRuns,
                isWicket = isWicket,
                wicketType = wicketType.name,
                dismissedPlayerId = resolvedDismissedId,
                fielderId = fielderId,
                countsAsLegalBall = countsAsLegalBall
            )

            repository.insertDelivery(delivery)

            // Recompute derived state synchronously with new delivery so MatchEntity active slots stay synced
            val allTeams = repository.observeAllTeams().first()
            val allPlayers = repository.observeAllPlayers().first()
            val updatedDeliveries = existingDeliveries + delivery
            val derived = CricketScoringEngine.buildLiveState(
                match = state.match.copy(
                    activeStrikerId = null,
                    activeNonStrikerId = null,
                    activeBowlerId = null
                ),
                deliveries = updatedDeliveries,
                teamA = allTeams.first { it.id == state.teamA.id },
                teamB = allTeams.first { it.id == state.teamB.id },
                allPlayers = allPlayers
            )

            val newStatus: String
            val newTarget: Int?
            val newResult: String
            val winnerId: Long?

            if (state.match.currentInnings == 1 && derived.innings1.isCompleted) {
                newStatus = "INNINGS_BREAK"
                newTarget = derived.innings1.totalRuns + 1
                newResult = ""
                winnerId = null
            } else if (state.match.currentInnings == 2 && derived.innings2?.isCompleted == true) {
                newStatus = "COMPLETED"
                newTarget = derived.innings1.totalRuns + 1
                newResult = CricketScoringEngine.computeMatchResult(derived.innings1, derived.innings2)
                winnerId = when {
                    derived.innings2.totalRuns >= newTarget -> derived.innings2.battingTeam.id
                    derived.innings2.totalRuns < derived.innings1.totalRuns -> derived.innings1.battingTeam.id
                    else -> null
                }
            } else {
                newStatus = "IN_PROGRESS"
                newTarget = state.match.targetRuns
                newResult = ""
                winnerId = null
            }

            repository.updateMatch(
                state.match.copy(
                    status = newStatus,
                    targetRuns = newTarget,
                    resultSummary = newResult,
                    winnerTeamId = winnerId,
                    activeStrikerId = derived.activeInnings.strikerId,
                    activeNonStrikerId = derived.activeInnings.nonStrikerId,
                    activeBowlerId = derived.activeInnings.currentBowlerId
                )
            )

            // Trigger lightweight animation overlay
            val event = when {
                isWicket -> ScoringCelebration.WICKET
                runsOffBat == 6 -> ScoringCelebration.SIX
                runsOffBat == 4 -> ScoringCelebration.FOUR
                else -> ScoringCelebration.NONE
            }
            if (event != ScoringCelebration.NONE) {
                _celebration.value = event
                delay(1100)
                _celebration.value = ScoringCelebration.NONE
            }
        }
    }

    fun undoLastDelivery() {
        viewModelScope.launch {
            val state = liveState.value ?: return@launch
            val lastDelivery = repository.getLastDeliveryInMatch(matchId) ?: return@launch
            repository.deleteDeliveryById(lastDelivery.id)

            val remaining = repository.getDeliveriesOnce(matchId)
            val allTeams = repository.observeAllTeams().first()
            val allPlayers = repository.observeAllPlayers().first()

            val revertedInnings = lastDelivery.inningsNumber
            val updatedMatchBase = state.match.copy(
                currentInnings = revertedInnings,
                status = "IN_PROGRESS",
                winnerTeamId = null,
                resultSummary = "",
                targetRuns = if (revertedInnings == 1) null else state.match.targetRuns,
                activeStrikerId = null,
                activeNonStrikerId = null,
                activeBowlerId = null
            )

            val derived = CricketScoringEngine.buildLiveState(
                match = updatedMatchBase,
                deliveries = remaining,
                teamA = allTeams.first { it.id == state.teamA.id },
                teamB = allTeams.first { it.id == state.teamB.id },
                allPlayers = allPlayers
            )

            repository.updateMatch(
                updatedMatchBase.copy(
                    activeStrikerId = derived.activeInnings.strikerId,
                    activeNonStrikerId = derived.activeInnings.nonStrikerId,
                    activeBowlerId = derived.activeInnings.currentBowlerId
                )
            )
        }
    }

    fun swapStrike() {
        viewModelScope.launch {
            val state = liveState.value ?: return@launch
            val currentStriker = state.activeInnings.strikerId ?: return@launch
            val currentNonStriker = state.activeInnings.nonStrikerId ?: return@launch
            repository.updateMatch(
                state.match.copy(
                    activeStrikerId = currentNonStriker,
                    activeNonStrikerId = currentStriker
                )
            )
        }
    }

    fun selectNextBatter(playerId: Long) {
        viewModelScope.launch {
            val state = liveState.value ?: return@launch
            val updated = if (state.activeInnings.strikerId == null) {
                state.match.copy(activeStrikerId = playerId)
            } else {
                state.match.copy(activeNonStrikerId = playerId)
            }
            repository.updateMatch(updated)
        }
    }

    fun selectNextBowler(playerId: Long) {
        viewModelScope.launch {
            val state = liveState.value ?: return@launch
            repository.updateMatch(state.match.copy(activeBowlerId = playerId))
        }
    }

    fun startSecondInnings(strikerId: Long, nonStrikerId: Long, bowlerId: Long) {
        viewModelScope.launch {
            val state = liveState.value ?: return@launch
            val target = state.innings1.totalRuns + 1
            repository.updateMatch(
                state.match.copy(
                    currentInnings = 2,
                    status = "IN_PROGRESS",
                    targetRuns = target,
                    innings2StrikerId = strikerId,
                    innings2NonStrikerId = nonStrikerId,
                    innings2BowlerId = bowlerId,
                    activeStrikerId = strikerId,
                    activeNonStrikerId = nonStrikerId,
                    activeBowlerId = bowlerId
                )
            )
        }
    }

    fun endCurrentInningsManually() {
        viewModelScope.launch {
            val state = liveState.value ?: return@launch
            if (state.match.currentInnings == 1) {
                repository.updateMatch(
                    state.match.copy(
                        status = "INNINGS_BREAK",
                        targetRuns = state.innings1.totalRuns + 1
                    )
                )
            } else if (state.innings2 != null) {
                val result = CricketScoringEngine.computeMatchResult(state.innings1, state.innings2)
                val target = state.innings1.totalRuns + 1
                val winnerId = when {
                    state.innings2.totalRuns >= target -> state.innings2.battingTeam.id
                    state.innings2.totalRuns < state.innings1.totalRuns -> state.innings1.battingTeam.id
                    else -> null
                }
                repository.updateMatch(
                    state.match.copy(
                        status = "COMPLETED",
                        resultSummary = result,
                        winnerTeamId = winnerId
                    )
                )
            }
        }
    }
}

class TeamsAndPlayersViewModel(private val repository: CricyRepository) : ViewModel() {
    val teams: StateFlow<List<TeamEntity>> = repository.observeAllTeams()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val players: StateFlow<List<PlayerEntity>> = repository.observeAllPlayers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun createTeam(name: String, shortName: String, accentHex: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.createTeam(name, shortName, accentHex)
        }
    }

    fun updateTeam(team: TeamEntity) {
        viewModelScope.launch { repository.updateTeam(team) }
    }

    fun deleteTeam(team: TeamEntity) {
        viewModelScope.launch { repository.deleteTeam(team) }
    }

    fun savePlayer(
        existingId: Long = 0L,
        teamId: Long,
        name: String,
        role: String,
        battingStyle: String,
        bowlingStyle: String,
        jerseyNumber: Int,
        photoUri: String?
    ) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.savePlayer(
                PlayerEntity(
                    id = existingId,
                    teamId = teamId,
                    name = name.trim(),
                    role = role,
                    battingStyle = battingStyle,
                    bowlingStyle = bowlingStyle,
                    jerseyNumber = jerseyNumber,
                    photoUri = photoUri
                )
            )
        }
    }

    fun deletePlayer(player: PlayerEntity) {
        viewModelScope.launch { repository.deletePlayer(player) }
    }

    suspend fun persistPhoto(uri: Uri): String? = repository.persistPlayerPhoto(uri)
}

class StatisticsViewModel(private val repository: CricyRepository) : ViewModel() {
    val teams: StateFlow<List<TeamEntity>> = repository.observeAllTeams()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playerStats: StateFlow<List<PlayerCareerStats>> = combine(
        repository.observeAllPlayers(),
        repository.observeAllTeams(),
        repository.observeAllMatches(),
        repository.observeAllDeliveries()
    ) { players, teams, matches, deliveries ->
        PlayerStatsCalculator.calculateAllPlayerStats(
            players = players,
            teams = teams,
            matches = matches,
            deliveries = deliveries
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

class PlayerProfileViewModel(
    private val repository: CricyRepository,
    private val playerId: Long
) : ViewModel() {
    val teams: StateFlow<List<TeamEntity>> = repository.observeAllTeams()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playerStats: StateFlow<PlayerCareerStats?> = combine(
        repository.observeAllPlayers(),
        repository.observeAllTeams(),
        repository.observeAllMatches(),
        repository.observeAllDeliveries()
    ) { players, teams, matches, deliveries ->
        val targetPlayer = players.firstOrNull { it.id == playerId } ?: return@combine null
        PlayerStatsCalculator.calculateAllPlayerStats(
            players = listOf(targetPlayer),
            teams = teams,
            matches = matches,
            deliveries = deliveries
        ).firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun updatePlayer(player: PlayerEntity) {
        viewModelScope.launch { repository.savePlayer(player) }
    }

    suspend fun persistPhoto(uri: Uri): String? = repository.persistPlayerPhoto(uri)
}

class MatchHistoryViewModel(private val repository: CricyRepository) : ViewModel() {
    val matches: StateFlow<List<MatchSummaryItem>> = combine(
        repository.observeAllMatches(),
        repository.observeAllTeams(),
        repository.observeAllPlayers(),
        repository.observeAllDeliveries()
    ) { matches, teams, players, deliveries ->
        val teamMap = teams.associateBy { it.id }
        val deliveriesByMatch = deliveries.groupBy { it.matchId }
        matches.map { m ->
            val tA = teamMap[m.teamAId]
            val tB = teamMap[m.teamBId]
            val summary = if (tA != null && tB != null) {
                val state = CricketScoringEngine.buildLiveState(
                    match = m,
                    deliveries = deliveriesByMatch[m.id].orEmpty(),
                    teamA = tA,
                    teamB = tB,
                    allPlayers = players
                )
                val i1 = "${state.innings1.battingTeam.shortName} ${state.innings1.totalRuns}/${state.innings1.wickets} (${state.innings1.oversDisplay})"
                val i2 = state.innings2?.let {
                    " vs ${it.battingTeam.shortName} ${it.totalRuns}/${it.wickets} (${it.oversDisplay})"
                } ?: ""
                i1 + i2
            } else {
                ""
            }
            MatchSummaryItem(match = m, teamA = tA, teamB = tB, liveScoreLine = summary)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun deleteMatch(matchId: Long) {
        viewModelScope.launch { repository.deleteMatch(matchId) }
    }
}

class ScorecardViewModel(
    private val repository: CricyRepository,
    private val matchId: Long
) : ViewModel() {
    val liveState: StateFlow<MatchLiveState?> = combine(
        repository.observeMatch(matchId),
        repository.observeDeliveriesForMatch(matchId),
        repository.observeAllTeams(),
        repository.observeAllPlayers()
    ) { match, deliveries, teams, players ->
        if (match == null) return@combine null
        val tA = teams.firstOrNull { it.id == match.teamAId } ?: return@combine null
        val tB = teams.firstOrNull { it.id == match.teamBId } ?: return@combine null
        CricketScoringEngine.buildLiveState(match, deliveries, tA, tB, players)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
}

class SettingsViewModel(private val repository: CricyRepository) : ViewModel() {
    val settings: StateFlow<CricySettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CricySettings())

    fun setHapticFeedback(enabled: Boolean) {
        viewModelScope.launch { repository.setHapticFeedback(enabled) }
    }

    fun setCelebrationAnimations(enabled: Boolean) {
        viewModelScope.launch { repository.setCelebrationAnimations(enabled) }
    }

    fun setConfirmUndo(enabled: Boolean) {
        viewModelScope.launch { repository.setConfirmUndo(enabled) }
    }

    fun setDefaultFormat(format: String) {
        viewModelScope.launch { repository.setDefaultFormat(format) }
    }

    fun setDefaultCustomOvers(overs: Int) {
        viewModelScope.launch { repository.setDefaultCustomOvers(overs) }
    }

    fun setScorerName(name: String) {
        viewModelScope.launch { repository.setScorerName(name) }
    }
}
