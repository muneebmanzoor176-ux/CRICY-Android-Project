package com.cricy.app

import android.app.Application
import com.cricy.app.di.AppContainer

class CricyApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
