package com.cricy.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.cricy.app.data.local.entity.DeliveryEntity
import com.cricy.app.data.local.entity.MatchEntity
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TeamDao {
    @Query("SELECT * FROM teams ORDER BY name ASC")
    fun observeAllTeams(): Flow<List<TeamEntity>>

    @Query("SELECT * FROM teams WHERE id = :teamId")
    suspend fun getTeamById(teamId: Long): TeamEntity?

    @Query("SELECT COUNT(*) FROM teams")
    suspend fun countTeams(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeam(team: TeamEntity): Long

    @Update
    suspend fun updateTeam(team: TeamEntity)

    @Delete
    suspend fun deleteTeam(team: TeamEntity)
}

@Dao
interface PlayerDao {
    @Query("SELECT * FROM players ORDER BY name ASC")
    fun observeAllPlayers(): Flow<List<PlayerEntity>>

    @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY jerseyNumber ASC, name ASC")
    fun observePlayersByTeam(teamId: Long): Flow<List<PlayerEntity>>

    @Query("SELECT * FROM players WHERE id = :playerId")
    fun observePlayerById(playerId: Long): Flow<PlayerEntity?>

    @Query("SELECT * FROM players WHERE id = :playerId")
    suspend fun getPlayerById(playerId: Long): PlayerEntity?

    @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY id ASC")
    suspend fun getPlayersByTeamOnce(teamId: Long): List<PlayerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayers(players: List<PlayerEntity>)

    @Update
    suspend fun updatePlayer(player: PlayerEntity)

    @Delete
    suspend fun deletePlayer(player: PlayerEntity)
}

@Dao
interface MatchDao {
    @Query("SELECT * FROM matches ORDER BY updatedAt DESC")
    fun observeAllMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches WHERE status != 'COMPLETED' ORDER BY updatedAt DESC")
    fun observeUnfinishedMatches(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches WHERE id = :matchId")
    fun observeMatch(matchId: Long): Flow<MatchEntity?>

    @Query("SELECT * FROM matches WHERE id = :matchId")
    suspend fun getMatchById(matchId: Long): MatchEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchEntity): Long

    @Update
    suspend fun updateMatch(match: MatchEntity)

    @Query("DELETE FROM matches WHERE id = :matchId")
    suspend fun deleteMatchById(matchId: Long)
}

@Dao
interface DeliveryDao {
    @Query("SELECT * FROM deliveries ORDER BY matchId ASC, inningsNumber ASC, sequenceNumber ASC")
    fun observeAllDeliveries(): Flow<List<DeliveryEntity>>

    @Query("SELECT * FROM deliveries WHERE matchId = :matchId ORDER BY inningsNumber ASC, sequenceNumber ASC")
    fun observeDeliveriesForMatch(matchId: Long): Flow<List<DeliveryEntity>>

    @Query("SELECT * FROM deliveries WHERE matchId = :matchId ORDER BY inningsNumber ASC, sequenceNumber ASC")
    suspend fun getDeliveriesForMatchOnce(matchId: Long): List<DeliveryEntity>

    @Query(
        "SELECT * FROM deliveries WHERE matchId = :matchId AND inningsNumber = :inningsNumber " +
            "ORDER BY sequenceNumber DESC LIMIT 1"
    )
    suspend fun getLastDeliveryInInnings(matchId: Long, inningsNumber: Int): DeliveryEntity?

    @Query("SELECT * FROM deliveries WHERE matchId = :matchId ORDER BY inningsNumber DESC, sequenceNumber DESC LIMIT 1")
    suspend fun getLastDeliveryInMatch(matchId: Long): DeliveryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDelivery(delivery: DeliveryEntity): Long

    @Query("DELETE FROM deliveries WHERE id = :deliveryId")
    suspend fun deleteDeliveryById(deliveryId: Long)
}
