package com.cricy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.cricy.app.ui.navigation.CricyNavGraph
import com.cricy.app.ui.theme.CricyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repository = (application as CricyApplication).container.repository
        setContent {
            CricyTheme {
                CricyNavGraph(repository = repository)
            }
        }
    }
}
