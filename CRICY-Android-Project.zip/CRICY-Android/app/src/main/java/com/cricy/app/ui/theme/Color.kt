package com.cricy.app.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Deep Black Canvas (60%)
val CricyBlack = Color(0xFF050608)
val CricySurface = Color(0xFF0D1016)
val CricySurfaceElevated = Color(0xFF141923)
val CricySurfaceBorder = Color(0xFF28303D)

// Metallic Silver Primary (30%)
val SilverBright = Color(0xFFF0F3F8)
val SilverPrimary = Color(0xFFC9D0DA)
val SilverMid = Color(0xFF969FAD)
val SilverDim = Color(0xFF5D6675)

// Premium Gold Secondary (10%)
val GoldBright = Color(0xFFF6DB7E)
val GoldPrimary = Color(0xFFD4AF37)
val GoldDeep = Color(0xFF9A771C)

// Semantic Broadcast Colors (paired with text/labels)
val WicketCrimson = Color(0xFFE53935)
val WicketCrimsonDark = Color(0xFF471214)
val BoundaryBlue = Color(0xFF64B5F6)
val BoundaryBlueDark = Color(0xFF102A43)
val ExtraAmber = Color(0xFFFFB74D)
val ExtraAmberDark = Color(0xFF33230C)
val WinEmerald = Color(0xFF4CAF50)

val SilverMetallicBrush = Brush.linearGradient(
    colors = listOf(SilverBright, SilverPrimary, SilverMid)
)

val SilverButtonBrush = Brush.verticalGradient(
    colors = listOf(Color(0xFF2B323F), Color(0xFF181D26))
)

val GoldMetallicBrush = Brush.linearGradient(
    colors = listOf(GoldBright, GoldPrimary, GoldDeep)
)

val GoldButtonBrush = Brush.verticalGradient(
    colors = listOf(Color(0xFFE5C158), Color(0xFFC49A28))
)
