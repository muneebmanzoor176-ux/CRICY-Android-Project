package com.cricy.app.domain

import com.cricy.app.data.local.entity.DeliveryEntity
import com.cricy.app.data.local.entity.MatchEntity
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import com.cricy.app.domain.engine.CricketScoringEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CricketScoringEngineTest {

    private val teamA = TeamEntity(id = 1L, name = "Silver Strikers", shortName = "SLV")
    private val teamB = TeamEntity(id = 2L, name = "Gold Royals", shortName = "GLD")

    private val players = listOf(
        PlayerEntity(id = 101L, teamId = 1L, name = "Batter One"),
        PlayerEntity(id = 102L, teamId = 1L, name = "Batter Two"),
        PlayerEntity(id = 103L, teamId = 1L, name = "Batter Three"),
        PlayerEntity(id = 201L, teamId = 2L, name = "Bowler One"),
        PlayerEntity(id = 202L, teamId = 2L, name = "Bowler Two"),
        PlayerEntity(id = 203L, teamId = 2L, name = "Bowler Three")
    )

    private fun baseMatch(format: String = "CUSTOM", overs: Int = 2): MatchEntity =
        MatchEntity(
            id = 1L,
            format = format,
            oversLimit = overs,
            teamAId = 1L,
            teamBId = 2L,
            teamASquadIdsCsv = "101,102,103",
            teamBSquadIdsCsv = "201,202,203",
            tossWinnerTeamId = 1L,
            tossDecision = "BAT",
            battingFirstTeamId = 1L,
            currentInnings = 1,
            innings1StrikerId = 101L,
            innings1NonStrikerId = 102L,
            innings1BowlerId = 201L
        )

    @Test
    fun t20_and_odi_overs_limits_and_strike_rotation() {
        val t20Match = baseMatch(format = "T20", overs = 20)
        val deliveries = listOf(
            DeliveryEntity(id = 1, matchId = 1, inningsNumber = 1, sequenceNumber = 1, overNumber = 0, ballInOver = 1, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 1, countsAsLegalBall = true),
            DeliveryEntity(id = 2, matchId = 1, inningsNumber = 1, sequenceNumber = 2, overNumber = 0, ballInOver = 2, strikerId = 102, nonStrikerId = 101, bowlerId = 201, runsOffBat = 4, countsAsLegalBall = true),
            DeliveryEntity(id = 3, matchId = 1, inningsNumber = 1, sequenceNumber = 3, overNumber = 0, ballInOver = 3, strikerId = 102, nonStrikerId = 101, bowlerId = 201, runsOffBat = 6, countsAsLegalBall = true)
        )

        val state = CricketScoringEngine.buildLiveState(t20Match, deliveries, teamA, teamB, players)
        assertEquals(11, state.activeInnings.totalRuns)
        assertEquals("0.3", state.activeInnings.oversDisplay)
        // After 1 run on ball 1, 102 is on strike; 4 and 6 keep 102 on strike
        assertEquals(102L, state.activeInnings.strikerId)
        assertEquals(101L, state.activeInnings.nonStrikerId)

        val odiMatch = baseMatch(format = "ODI", overs = 50)
        val odiState = CricketScoringEngine.buildLiveState(odiMatch, emptyList(), teamA, teamB, players)
        assertEquals(50, odiState.activeInnings.oversLimit)
        assertEquals(300, odiState.activeInnings.remainingBalls)
    }

    @Test
    fun extras_wide_noball_bye_legbye_handled_correctly() {
        val match = baseMatch(format = "CUSTOM", overs = 2)
        val deliveries = listOf(
            // Wide + 0 additional -> 1 extra, 0 legal balls
            DeliveryEntity(id = 1, matchId = 1, inningsNumber = 1, sequenceNumber = 1, overNumber = 0, ballInOver = 0, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 0, extraType = "WIDE", extraRuns = 1, countsAsLegalBall = false),
            // No ball + 4 off bat -> 5 runs total, 0 legal balls
            DeliveryEntity(id = 2, matchId = 1, inningsNumber = 1, sequenceNumber = 2, overNumber = 0, ballInOver = 0, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 4, extraType = "NO_BALL", extraRuns = 1, countsAsLegalBall = false),
            // 1 Bye -> legal ball, 1 run, swaps strike to 102, bowler NOT charged
            DeliveryEntity(id = 3, matchId = 1, inningsNumber = 1, sequenceNumber = 3, overNumber = 0, ballInOver = 1, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 0, extraType = "BYE", extraRuns = 1, countsAsLegalBall = true),
            // 2 Leg Byes -> legal ball, 2 runs, keeps 102 on strike
            DeliveryEntity(id = 4, matchId = 1, inningsNumber = 1, sequenceNumber = 4, overNumber = 0, ballInOver = 2, strikerId = 102, nonStrikerId = 101, bowlerId = 201, runsOffBat = 0, extraType = "LEG_BYE", extraRuns = 2, countsAsLegalBall = true)
        )

        val state = CricketScoringEngine.buildLiveState(match, deliveries, teamA, teamB, players)
        assertEquals(9, state.activeInnings.totalRuns)
        assertEquals("0.2", state.activeInnings.oversDisplay)
        assertEquals(5, state.activeInnings.extras.total)
        assertEquals(1, state.activeInnings.extras.wides)
        assertEquals(1, state.activeInnings.extras.noBalls)
        assertEquals(1, state.activeInnings.extras.byes)
        assertEquals(2, state.activeInnings.extras.legByes)
        assertEquals(102L, state.activeInnings.strikerId)

        val bowler = state.activeInnings.bowlers.first { it.player.id == 201L }
        // Bowler charged 1 (wide) + 5 (no ball + 4 off bat) = 6; byes/leg-byes excluded
        assertEquals(6, bowler.runsConceded)
    }

    @Test
    fun maiden_over_and_end_of_over_bowler_prompt() {
        val match = baseMatch(format = "CUSTOM", overs = 5)
        val deliveries = (1..6).map { ball ->
            DeliveryEntity(
                id = ball.toLong(),
                matchId = 1,
                inningsNumber = 1,
                sequenceNumber = ball,
                overNumber = 0,
                ballInOver = ball,
                strikerId = 101,
                nonStrikerId = 102,
                bowlerId = 201,
                runsOffBat = 0,
                countsAsLegalBall = true
            )
        }

        val state = CricketScoringEngine.buildLiveState(match, deliveries, teamA, teamB, players)
        assertEquals("1.0", state.activeInnings.oversDisplay)
        assertEquals(1, state.activeInnings.bowlers.first().maidens)
        // Strike swapped at end of over
        assertEquals(102L, state.activeInnings.strikerId)
        // Needs next bowler, and bowler 201 is excluded from consecutive overs
        assertTrue(state.needsNextBowler)
        assertNull(state.activeInnings.currentBowlerId)
        assertFalse(state.availableNextBowlers.any { it.id == 201L })
    }

    @Test
    fun wicket_run_out_and_undo_restores_exact_state() {
        val match = baseMatch(format = "CUSTOM", overs = 2)
        val ball1 = DeliveryEntity(id = 1, matchId = 1, inningsNumber = 1, sequenceNumber = 1, overNumber = 0, ballInOver = 1, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 4, countsAsLegalBall = true)
        val ball2 = DeliveryEntity(id = 2, matchId = 1, inningsNumber = 1, sequenceNumber = 2, overNumber = 0, ballInOver = 2, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 0, isWicket = true, wicketType = "BOWLED", dismissedPlayerId = 101, countsAsLegalBall = true)

        val afterWicket = CricketScoringEngine.buildLiveState(match, listOf(ball1, ball2), teamA, teamB, players)
        assertEquals(1, afterWicket.activeInnings.wickets)
        assertTrue(afterWicket.needsNextBatter)
        assertEquals(1, afterWicket.activeInnings.fallOfWickets.size)
        assertEquals(1, afterWicket.activeInnings.bowlers.first().wickets)

        // Simulate UNDO by removing ball2
        val afterUndo = CricketScoringEngine.buildLiveState(match, listOf(ball1), teamA, teamB, players)
        assertEquals(0, afterUndo.activeInnings.wickets)
        assertEquals(4, afterUndo.activeInnings.totalRuns)
        assertFalse(afterUndo.needsNextBatter)
        assertEquals(101L, afterUndo.activeInnings.strikerId)
    }

    @Test
    fun innings_chase_target_rrr_and_match_result() {
        val match = baseMatch(format = "CUSTOM", overs = 1).copy(
            currentInnings = 2,
            innings2StrikerId = 201L,
            innings2NonStrikerId = 202L,
            innings2BowlerId = 103L
        )
        val deliveries = listOf(
            // Innings 1: 6 balls -> 12 runs (Target = 13)
            DeliveryEntity(id = 1, matchId = 1, inningsNumber = 1, sequenceNumber = 1, overNumber = 0, ballInOver = 1, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 6, countsAsLegalBall = true),
            DeliveryEntity(id = 2, matchId = 1, inningsNumber = 1, sequenceNumber = 2, overNumber = 0, ballInOver = 2, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 6, countsAsLegalBall = true),
            DeliveryEntity(id = 3, matchId = 1, inningsNumber = 1, sequenceNumber = 3, overNumber = 0, ballInOver = 3, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 0, countsAsLegalBall = true),
            DeliveryEntity(id = 4, matchId = 1, inningsNumber = 1, sequenceNumber = 4, overNumber = 0, ballInOver = 4, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 0, countsAsLegalBall = true),
            DeliveryEntity(id = 5, matchId = 1, inningsNumber = 1, sequenceNumber = 5, overNumber = 0, ballInOver = 5, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 0, countsAsLegalBall = true),
            DeliveryEntity(id = 6, matchId = 1, inningsNumber = 1, sequenceNumber = 6, overNumber = 0, ballInOver = 6, strikerId = 101, nonStrikerId = 102, bowlerId = 201, runsOffBat = 0, countsAsLegalBall = true),
            // Innings 2: 6, 6, 4 -> 16 runs -> Chasing team wins by 2 wickets!
            DeliveryEntity(id = 7, matchId = 1, inningsNumber = 2, sequenceNumber = 1, overNumber = 0, ballInOver = 1, strikerId = 201, nonStrikerId = 202, bowlerId = 103, runsOffBat = 6, countsAsLegalBall = true),
            DeliveryEntity(id = 8, matchId = 1, inningsNumber = 2, sequenceNumber = 2, overNumber = 0, ballInOver = 2, strikerId = 201, nonStrikerId = 202, bowlerId = 103, runsOffBat = 6, countsAsLegalBall = true),
            DeliveryEntity(id = 9, matchId = 1, inningsNumber = 2, sequenceNumber = 3, overNumber = 0, ballInOver = 3, strikerId = 201, nonStrikerId = 202, bowlerId = 103, runsOffBat = 4, countsAsLegalBall = true)
        )

        val state = CricketScoringEngine.buildLiveState(match, deliveries, teamA, teamB, players)
        assertTrue(state.isMatchCompleted)
        assertEquals(13, state.innings2?.targetRuns)
        assertEquals("Gold Royals won by 2 wickets", state.resultSummary)
    }
}
